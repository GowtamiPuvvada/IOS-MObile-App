//
//  patientProfilevc.swift
//  DreamMom
//
//  Created by SAIL on 30/11/23.
//

import UIKit

class patientProfilevc: UIViewController {

    @IBOutlet weak var logoutBtn: UIButton!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var patientnameLBL: UILabel!
    @IBOutlet weak var patientidLBL: UILabel!
    @IBOutlet weak var bloodgrpLBL: UILabel!
    @IBOutlet weak var patientcontactLBL: UILabel!
    @IBOutlet weak var YOMLBL: UILabel!
    var pid1 : String?
    var patientlogindisplay: patientlogindisplayModel?
    override func viewDidLoad() {
        super.viewDidLoad()

        fetchData()
    }
    func fetchData() {
        guard let userId = self.pid1  else {
                print("User ID is nil")
                return
            }
        let formData = [
                    "userid": userId,
                ]
        APIHandler().postAPIValues(type: patientlogindisplayModel.self, apiUrl: ServiceAPI.PatientlogindisplayURL , method: "POST", formData: formData) {
            [weak self] result in
                switch result {
                case .success(let patientlogindisplay):
                    self?.patientlogindisplay = patientlogindisplay
                    // Update UI with patient details (replace these lines with your outlets)
                    DispatchQueue.main.async {
                        
                        self?.patientnameLBL.text = patientlogindisplay.patientdisplay.first?.name
                        self?.patientidLBL.text = patientlogindisplay.patientdisplay.first?.userid
                        self?.bloodgrpLBL.text = patientlogindisplay.patientdisplay.first?.bloodgroup
                        self?.patientcontactLBL.text = patientlogindisplay.patientdisplay.first?.contactNo
                        self?.YOMLBL.text = patientlogindisplay.patientdisplay.first?.marriageyear
                        
                       
                    }
                case .failure(let error):
                    print("Error fetching patient details: \(error)")
                }
            }
        }

    @IBAction func logoutBtn(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "patientLoginvc") as! patientLoginvc
                self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func bckbtn(_ sender: Any) {
       // self.navigationController?.popViewController(animated: true)
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "patienthomePagevc") as! patienthomePagevc
        vc.pid1 = self.pid1!
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
