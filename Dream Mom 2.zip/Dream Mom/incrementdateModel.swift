//
//  incrementdateModel.swift
//  DreamMom
//
//  Created by k. Dharani on 12/03/24.
//

import Foundation

// MARK: - Welcome
struct incrementdateModel: Codable {
    let status: Bool
    let cycleupdate: [Cycleupdate1]
}

// MARK: - Cycleupdate
struct Cycleupdate1: Codable {
    let date: String
}
