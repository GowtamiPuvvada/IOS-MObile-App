//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit



struct ServiceAPI {

    static let baseURL = "http://192.168.146.118/"
    static let LogInURL = baseURL+"infertility/dr_login.php?"
    static let drProfiledisplayURL = baseURL+"infertility/dr_profiledisplay.php"
    static let editprofile = baseURL+"infertility/dr_profileupdate.php"
    static let addpatientURL = baseURL+"infertility/addpatient.php"
    static let addspouseURL = baseURL+"infertility/addspouse.php"
    static let addspecificationsURL = baseURL+"infertility/addspecifications.php"
    static let ViewPatientListURL = baseURL+"infertility/patientlist.php"
    static let ViewPatientURL = baseURL+"infertility/viewpatientdetails.php"
    static let AddMedicationsURL = baseURL+"infertility/medications.php"
    static let ViewSpouseURL = baseURL+"infertility/viewspousedetails.php"
    static let AddReportsURL = baseURL+"infertility/addreports.php"
    static let ViewMedicationsURL = baseURL+"infertility/viewmedicaldetails.php"
    static let ViewStatusModelURL = baseURL+"infertility/viewreports.php"
    static let AddAdvicesURL = baseURL+"infertility/addadvices.php"
    static let ViewAdvicesURL = baseURL+"infertility/viewadvices.php"
    static let sviewadviceURL = baseURL+"infertility/viewspecificadvice.php"
    static let cycleviewURL = baseURL+"infertility/viewcycleupdate.php"
    static let PatientloginURL = baseURL+"infertility/patientlogin.php"
    static let PatientlogindisplayURL = baseURL+"infertility/patientlogindisplay.php"
    static let cycleupdatePURL = baseURL+"infertility/updatecycle.php"
    static let editpatientprofileURL = baseURL+"infertility/updatepatientdetails.php"
    static let uploadimgURL = baseURL+"infertility/uploadimg.php"
    static let graphURL = baseURL+"infertility/graph.php?"
    static let specificationsURL = baseURL+"infertility/viewspecifications.php"
    static let searchURL = baseURL+"infertility/search.php"
    static let passwordURL = baseURL+"infertility/password.php"
    static let viewimgURL = baseURL+"infertility/viewimg.php"
    static let sidenameURL = baseURL+"infertility/sidename.php"
    static let monthdayURL = baseURL+"infertility/nextmonth.php"
    static let adddocteridURL = baseURL+"infertility/adddocterid.php"
    static let adddocterdetailsURL = baseURL+"infertility/adddoctor.php"
    static let doctorlistURL = baseURL+"infertility/doctorlist.php"
    static let doctorsearchURL = baseURL+"infertility/doctorsearch.php"
    static let docpassURL = baseURL+"infertility/passdoc.php"
    static let patientidURL = baseURL+"infertility/patientid.php"
    static let incerementdateURL = baseURL+"infertility/incerementdate.php"
}


