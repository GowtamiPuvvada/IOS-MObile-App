//
//  UserDefault.swift
//  building management
//
//  Created by SAIL on 09/10/23.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()

    private let userDefaults = UserDefaults.standard

    private init() {}

    // MARK: - Define Keys for Your Data
    private let userIdKey = "UserId"
    
    private let userAgeKey = "UserAge"
    
    private let userProfileKey = "UserProfile"
    
    private let busIdKey = "BusId"
    
    private let boardingPointKey = "BoardingPoint"
    
    private let key = "Key"

    // MARK: - Save Data
    func saveUserId(_ name: String) {
        userDefaults.set(name, forKey: userIdKey)
    }

    func saveUserAge(_ age: Int) {
        userDefaults.set(age, forKey: userAgeKey)
    }
    
    func saveUserProfile(_ profile: String) {
        userDefaults.set(profile, forKey: userProfileKey)
    }
    
    func saveBusId(_ bus: String) {
        userDefaults.set(bus, forKey: busIdKey)
    }
    
    func saveBoardingPoint(_ boardingPoint: String) {
        userDefaults.set(boardingPoint, forKey: boardingPointKey)
    }
    
    func saveKey(_ boardingPoint: String) {
        userDefaults.set(boardingPoint, forKey: key)
    }

    // MARK: - Retrieve Data
    func getUserID() -> String? {
        return userDefaults.string(forKey: userIdKey)
    }

    func getUserAge() -> Int {
        return userDefaults.integer(forKey: userAgeKey)
    }
    
    func getUserProfile() -> String? {
        return userDefaults.string(forKey: userProfileKey)
    }
    
    func getBusID() -> String? {
        return userDefaults.string(forKey: busIdKey)
    }
    
    func getBoardingPoint() -> String? {
        return userDefaults.string(forKey: boardingPointKey)
    }
    
    func getKey() -> String? {
        return userDefaults.string(forKey: key)
    }

    // MARK: - Remove Data (if needed)
    func removeUserData() {
        userDefaults.removeObject(forKey: userIdKey)
        userDefaults.removeObject(forKey: userAgeKey)
    }
}

