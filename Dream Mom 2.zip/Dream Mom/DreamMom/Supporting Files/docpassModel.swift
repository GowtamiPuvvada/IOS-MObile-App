//
//  docpassModel.swift
//  DreamMom
//
//  Created by k. Dharani on 09/03/24.
//

import Foundation

// MARK: - Welcome
struct docpassModel: Codable {
    let status: Bool
    let message: String
}

