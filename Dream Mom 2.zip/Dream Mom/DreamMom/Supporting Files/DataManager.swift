//
//  DataManager.swift
//  DreamMom
//
//  Created by SAIL on 31/01/24.
//

import UIKit


class DataManager {
    
  
        static let shared = DataManager()
        
        private init() {
            // Private initialization to ensure just one instance is created.
        }
   
     var patientNamw = String()
    var cycle = String()
   
}



    
   
    class LoadingIndicator {

        static let shared = LoadingIndicator()

        private let activityIndicator: UIActivityIndicatorView = {
            let indicator = UIActivityIndicatorView(style: .large)
            indicator.color = .Pink
            indicator.hidesWhenStopped = true
            return indicator
        }()

        private init() {}

        func showLoading(on view: UIView) {
            DispatchQueue.main.async {
                self.activityIndicator.center = view.center
                view.addSubview(self.activityIndicator)
                self.activityIndicator.startAnimating()
            }
        }

        func hideLoading() {
            
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.activityIndicator.stopAnimating()
                self.activityIndicator.removeFromSuperview()
            }
            
           
        }
    }
  
      
    

