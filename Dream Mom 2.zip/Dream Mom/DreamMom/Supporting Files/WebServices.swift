//
//  WebServices.swift
//  FIEXFIT
//
//  Created by Saranya Ravi on 16/11/23.
//

import Foundation

struct Webservices
{
    static let BaseUrl = "http://13.235.201.81/invoiceapp/api/"
    static let Login = BaseUrl + "login"
    static let updateProfile = BaseUrl + "update-profile"
    static let patientList = BaseUrl + ""
   
    
}
