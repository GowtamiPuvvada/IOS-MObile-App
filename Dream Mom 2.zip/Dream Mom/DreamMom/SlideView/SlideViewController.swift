//
//  SlideViewController.swift
//  DreamMom
//
//  Created by SAIL on 21/11/23.
//

import UIKit



protocol SlideViewDelegate: AnyObject {
    func setAction(index:Int)
}


class SlideViewController: UIViewController {
    
    
    
    weak var delegate: SlideViewDelegate?
        
    var pid: String?
    var namelist : nameModel?
    @IBOutlet weak var idLBL: UILabel!
    @IBOutlet weak var nameLBL: UILabel!
   
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchData()
       
    }
    func fetchData() {
            guard let userId = pid else {
                print("User ID is nil")
                return
            }
        let formData = [
                    "userid": userId,
                ]
        APIHandler().postAPIValues(type: nameModel.self, apiUrl: ServiceAPI.sidenameURL , method: "POST", formData: formData) {
            [weak self] result in
                switch result {
                case .success(let namelist):
                    self?.namelist = namelist
                    // Update UI with patient details (replace these lines with your outlets)
                    DispatchQueue.main.async {
                        
                        self?.nameLBL.text = namelist.name.name
                        self?.idLBL.text = namelist.name.userid
                        

                    }
                case .failure(let error):
                    print("Error fetching patient details: \(error)")
                }
            }
        }
    
    

    @IBAction func backBtnTapped(_ sender: Any) {
        
     
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func medicationTapped(_ sender: Any) {
        
        delegate?.setAction(index: 1)
        self.dismiss(animated: false, completion: nil)
    }
    
    
    @IBAction func viewreportsTapped(_ sender: Any) {
        delegate?.setAction(index: 2)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func ViewGraphTapped(_ sender: Any) {
        delegate?.setAction(index: 3)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func Spousedetailstapped(_ sender: Any) {
        delegate?.setAction(index: 4)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func AddReportsTapped(_ sender: Any) {
        delegate?.setAction(index: 5)
        self.dismiss(animated: false, completion: nil)
    }
    @IBAction func ViewAdvicesTapped(_ sender: Any) {
        delegate?.setAction(index: 6)
        self.dismiss(animated: false, completion: nil)
    }
    @IBAction func CycleUpdateTapped(_ sender: Any) {
        delegate?.setAction(index: 7)
        self.dismiss(animated: false, completion: nil)
    }
    @IBAction func Logout(_ sender: Any) {
        delegate?.setAction(index: 8)
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func EditTapped(_ sender: Any) {
        delegate?.setAction(index: 9)
        self.dismiss(animated: false, completion: nil)
    }
    
}
