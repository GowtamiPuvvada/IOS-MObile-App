//
//  AddPatientInfovc.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class AddPatientInfovc: UIViewController, UITextViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {

    @IBOutlet weak var ageTEXTFIELD: UITextField!
    @IBOutlet weak var idTEXTFIELD: UITextField!
    @IBOutlet weak var nameTEXTFIELD: UITextField!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var genderTEXTFIELD: UITextField!
    
    @IBOutlet weak var medicalhistoryTEXTFIELD: UITextView!
    @IBOutlet weak var bloodgroupTEXTFIELD: UITextField!
    @IBOutlet weak var marraigeyearTEXTFIELD: UITextField!
    @IBOutlet weak var addressTEXTVIEW: UITextView!
    @IBOutlet weak var contactnumberTEXTFIELD: UITextField!
    @IBOutlet weak var weightTEXTFIELD: UITextField!
    @IBOutlet weak var heightTEXTFIELD: UITextField!
    
    @IBOutlet weak var nextpage: UIButton!
    var userID: Int?
    
    let marriageYearPicker = UIPickerView()
    let marriageYearToolbar = UIToolbar()
    let years: [Int] = {
        let currentYear = Calendar.current.component(.year, from: Date())
        return Array((1900...currentYear).reversed())
    }()

    var id: String?
    let genderPicker = UIPickerView()
    let bloodGroupPicker = UIPickerView()
    let agePicker = UIPickerView()
    let ageToolPicker = UIToolbar()
    let genderToolbar = UIToolbar()
    let bloodGroupToolbar = UIToolbar()
    let datePicker = UIDatePicker()
    let genders = ["Male", "Female", "Other"]
    let bloodGroups = ["O+","O-","A+","A-","B+","B-","AB+","AB-"]
    let ageGroups = Array(18...100)
    let yearGroups: [Int] = {
        let currentYear = Calendar.current.component(.year, from: Date())
        return Array(1970...currentYear)
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        idTEXTFIELD.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        delegateIntialLoads()
        setupPickers()
        medicalhistoryTEXTFIELD.text = "Enter Medical History"
        medicalhistoryTEXTFIELD.textColor = UIColor.lightGray
        medicalhistoryTEXTFIELD.delegate = self
        addressTEXTVIEW.text = "Enter Address"
        addressTEXTVIEW.textColor = UIColor.lightGray
        addressTEXTVIEW.delegate = self
        if let userid = userID {
            idTEXTFIELD.text = String(userid)
        }
    }
    
    func delegateIntialLoads(){
        idTEXTFIELD.delegate = self
        nameTEXTFIELD.delegate = self
        genderTEXTFIELD.delegate = self
        medicalhistoryTEXTFIELD.delegate = self
        bloodgroupTEXTFIELD.delegate = self
        marraigeyearTEXTFIELD.delegate = self
        addressTEXTVIEW.delegate = self
        contactnumberTEXTFIELD.delegate = self
        weightTEXTFIELD.delegate = self
        heightTEXTFIELD.delegate = self
        ageTEXTFIELD.delegate = self
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            if textView == medicalhistoryTEXTFIELD {
                textView.text = "Medical History"
            } else if textView == addressTEXTVIEW {
                textView.text = "Address"
            }
            textView.textColor = UIColor.lightGray
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == contactnumberTEXTFIELD {
            // Allow backspace
            if string.isEmpty {
                return true
            }
            let newLength = (textField.text ?? "").count + string.count - range.length
            return newLength <= 10
        } else if textField == ageTEXTFIELD || textField == marraigeyearTEXTFIELD || textField == genderTEXTFIELD || textField == bloodgroupTEXTFIELD {
            showAlert(title: "Alert", message: "Please use the picker for this field.")
            return false
        }
        return true
    }

    @objc func marriageYearDoneButtonTapped() {
        marraigeyearTEXTFIELD.resignFirstResponder()
    }

    func calculateAge(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year], from: date, to: currentDate)
        return components.year ?? 0
    }

    func setupPickers() {
        genderPicker.delegate = self
        genderPicker.dataSource = self
        bloodGroupPicker.delegate = self
        bloodGroupPicker.dataSource = self
        agePicker.delegate = self
        agePicker.dataSource = self
        marriageYearPicker.delegate = self
        marriageYearPicker.dataSource = self
        marraigeyearTEXTFIELD.inputView = marriageYearPicker
        marraigeyearTEXTFIELD.inputAccessoryView = marriageYearToolbar
        ageTEXTFIELD.inputView = agePicker
        ageTEXTFIELD.inputAccessoryView = ageToolPicker
        genderTEXTFIELD.inputView = genderPicker
        bloodgroupTEXTFIELD.inputView = bloodGroupPicker
        genderTEXTFIELD.inputAccessoryView = genderToolbar
        bloodgroupTEXTFIELD.inputAccessoryView = bloodGroupToolbar
        setupToolbar(for: genderTEXTFIELD, with: genderPicker)
        setupToolbar(for: bloodgroupTEXTFIELD, with: bloodGroupPicker)
        setupToolbar(for: ageTEXTFIELD, with: agePicker)
        setupToolbar(for: marraigeyearTEXTFIELD, with: marriageYearPicker)
        ageToolPicker.sizeToFit()
        genderToolbar.sizeToFit()
        bloodGroupToolbar.sizeToFit()
        marriageYearToolbar.sizeToFit()
        let genderDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(genderDoneButtonTapped))
        let ageDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(ageDoneButtonTapped))
        let bloodGroupDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(bloodGroupDoneButtonTapped))
        let marriageDoneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(marriageYearDoneButtonTapped))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        genderToolbar.setItems([flexibleSpace, genderDoneButton], animated: false)
        ageToolPicker.setItems([flexibleSpace, ageDoneButton], animated: false)
        ageToolPicker.setItems([flexibleSpace, marriageDoneButton], animated: false)
        bloodGroupToolbar.setItems([flexibleSpace, bloodGroupDoneButton], animated: false)
    }
    
    func setupToolbar(for textField: UITextField, with picker: UIPickerView) {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([flexibleSpace, doneButton], animated: false)
        textField.inputAccessoryView = toolbar
    }
    
    @objc func doneButtonTapped() {
        view.endEditing(true)
    }
    
    @objc func genderDoneButtonTapped() {
        genderTEXTFIELD.resignFirstResponder()
    }
    
    @objc func ageDoneButtonTapped() {
        ageTEXTFIELD.resignFirstResponder()
    }
    
    @objc func bloodGroupDoneButtonTapped() {
        bloodgroupTEXTFIELD.resignFirstResponder()
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == genderPicker {
            return genders.count
        } else if pickerView == agePicker {
            return ageGroups.count
        } else if pickerView == marriageYearPicker {
            return yearGroups.count
        } else if pickerView == bloodGroupPicker {
            return bloodGroups.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == genderPicker {
            genderTEXTFIELD.text = genders[row]
            return genders[row]
        } else if pickerView == agePicker {
            ageTEXTFIELD.text = "\(ageGroups[row])"
            return "\(ageGroups[row])"
        } else if pickerView == marriageYearPicker {
            marraigeyearTEXTFIELD.text = "\(yearGroups[row])"
            return "\(yearGroups[row])"
        } else if pickerView == bloodGroupPicker {
            bloodgroupTEXTFIELD.text = bloodGroups[row]
            return bloodGroups[row]
        }
        return nil
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == genderPicker {
            genderTEXTFIELD.text = genders[row]
        } else if pickerView == agePicker {
            ageTEXTFIELD.text = "\(ageGroups[row])"
        } else if pickerView == marriageYearPicker {
            marraigeyearTEXTFIELD.text = "\(yearGroups[row])"
        } else if pickerView == bloodGroupPicker {
            bloodgroupTEXTFIELD.text = bloodGroups[row]
        }
    }

    @IBAction func nextpage(_ sender: Any) {
        guard let userId = idTEXTFIELD.text, !userId.isEmpty else {
            print("User ID is empty")
            showAlert(title: "Error", message: "User ID is required")
            return
        }
        
        guard let name = nameTEXTFIELD.text, !name.isEmpty else {
            print("Name is empty")
            showAlert(title: "Error", message: "Name is required")
            return
        }
        
        guard let contactNo = contactnumberTEXTFIELD.text, !contactNo.isEmpty else {
            print("Contact number is empty")
            showAlert(title: "Error", message: "Contact number is required")
            return
        }
        
        guard let age = ageTEXTFIELD.text, !age.isEmpty else {
            print("Age is empty")
            showAlert(title: "Error", message: "Age is required")
            return
        }
        
        guard let gender = genderTEXTFIELD.text, !gender.isEmpty else {
            print("Gender is empty")
            showAlert(title: "Error", message: "Gender is required")
            return
        }
        
        guard let height = heightTEXTFIELD.text, !height.isEmpty else {
            print("Height is empty")
            showAlert(title: "Error", message: "Height is required")
            return
        }
        
        guard let weight = weightTEXTFIELD.text, !weight.isEmpty else {
            print("Weight is empty")
            showAlert(title: "Error", message: "Weight is required")
            return
        }
        
        guard let address = addressTEXTVIEW.text, !address.isEmpty else {
            print("Address is empty")
            showAlert(title: "Error", message: "Address is required")
            return
        }
        
        guard let marriageYear = marraigeyearTEXTFIELD.text, !marriageYear.isEmpty else {
            print("Marriage year is empty")
            showAlert(title: "Error", message: "Marriage year is required")
            return
        }
        
        guard let bloodGroup = bloodgroupTEXTFIELD.text, !bloodGroup.isEmpty else {
            print("Blood group is empty")
            showAlert(title: "Error", message: "Blood group is required")
            return
        }
        
        guard let medicalHistory = medicalhistoryTEXTFIELD.text,
              medicalHistory != "Enter Medical History" && !medicalHistory.isEmpty else {
            print("Medical history is empty")
            showAlert(title: "Error", message: "Medical history is required")
            return
        }

        // If all fields are filled, proceed to submit the form data
        let formData = [
            "userid": userId,
            "name": name,
            "contactno": contactNo,
            "age": age,
            "gender": gender,
            "height": height,
            "weight": weight,
            "address": address,
            "marriageyear": marriageYear,
            "bloodgroup": bloodGroup,
            "medicalhistory": medicalHistory
        ]
        self.postPatientInfo(formData: formData)
    }


    @objc private func textFieldDidChange(_ textField: UITextField) {
        // No need to enable the nextpage button here
    }

    func postPatientInfo(formData: [String: String]) {
        APIHandler().postAPIValues(type: Welcome.self, apiUrl: ServiceAPI.addpatientURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                if data.status {
                    DispatchQueue.main.async { [self] in
                        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(withIdentifier: "AddSpouseController") as! AddSpouseController
                        vc.id = self!.id
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }
                } else {
                    DispatchQueue.main.async {
                        self?.showAlert(title: "Error", message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                self?.showAlert(title: "Error", message: "Failed to register patient, Please try again.")
            }
        }
    }
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }

    @IBAction func bckbtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
