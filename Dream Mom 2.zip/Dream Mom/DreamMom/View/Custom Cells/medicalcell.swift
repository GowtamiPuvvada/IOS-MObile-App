//
//  medicalcell.swift
//  DreamMom
//
//  Created by SAIL on 25/11/23.
//

import UIKit

class medicalcell: UITableViewCell {

    @IBOutlet weak var medicinename: UILabel!
    @IBOutlet weak var medicinequantity: UILabel!
    @IBOutlet weak var timing: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var when: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    override func layoutSubviews() {
        super.layoutSubviews()
       let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.frame.inset(by: margin)
          contentView.layer.cornerRadius = 10
          
          
       
      }
    
}
