//
//  AdviseCell.swift
//  DreamMom
//
//  Created by SAIL on 21/11/23.
//

import UIKit

class AdviseCell: UITableViewCell {
    
    
    
    @IBOutlet weak var dateLbl: UILabel!
    
    
    @IBOutlet weak var paraOneLbl: UILabel!
    
    
    @IBOutlet weak var paraTwoLbl: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
      override func layoutSubviews() {
          super.layoutSubviews()
         let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
          contentView.frame = contentView.frame.inset(by: margin)
            contentView.layer.cornerRadius = 15
        //  contentView.layer.shadowColor = UIColor.lightGray.cgColor
          self.layer.shadowColor = UIColor.gray.cgColor
              self.layer.shadowOffset = CGSize(width: 1, height: 1)
              self.layer.shadowOpacity = 1
         
        }
    
}
