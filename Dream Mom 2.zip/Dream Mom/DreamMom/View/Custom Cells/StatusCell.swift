//
//  StatusCell.swift
//  DreamMom
//
//  Created by SAIL on 25/11/23.
//

import UIKit

class StatusCell: UITableViewCell {

    @IBOutlet weak var day: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var lo: UILabel!
    @IBOutlet weak var ro: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
       let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        let borderLayer = CAShapeLayer()
                borderLayer.frame = contentView.bounds.inset(by: margin)
                borderLayer.borderWidth = 10.0 // Set the border width as needed
                borderLayer.borderColor = UIColor.black.cgColor // Set the border color
                
        
      contentView.frame = contentView.frame.inset(by: margin)
      contentView.layer.cornerRadius = 10
      }
    
}
