//
//  sopenadvicescell.swift
//  DreamMom
//
//  Created by vyas police on 19/12/23.
//

import UIKit

class sopenadvicescell: UITableViewCell {

    @IBOutlet weak var openAdvicesTEXTVIEW: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    override func layoutSubviews() {
        super.layoutSubviews()
       let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.frame.inset(by: margin)
          contentView.layer.cornerRadius = 15
      //  contentView.layer.shadowColor = UIColor.lightGray.cgColor
        self.layer.shadowColor = UIColor.gray.cgColor
            self.layer.shadowOffset = CGSize(width: 1, height: 1)
            self.layer.shadowOpacity = 1
       
      }
    
}
