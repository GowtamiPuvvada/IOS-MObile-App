//
//  MedicineForPatientCell.swift
//  DreamMom
//
//  Created by SAIL on 28/11/23.
//

import UIKit

class MedicineForPatientCell: UITableViewCell {

    @IBOutlet weak var medicineNameLbl: UILabel!
    @IBOutlet weak var quantityLbl: UILabel!
    @IBOutlet weak var timetotakeLbl: UILabel!
    @IBOutlet weak var dateLBL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
       let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        contentView.frame = contentView.frame.inset(by: margin)
          contentView.layer.cornerRadius = 15
     
      }
    
}
