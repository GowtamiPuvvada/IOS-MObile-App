//
//  ResetPassworddocVC.swift
//  DreamMom
//
//  Created by k. Dharani on 09/03/24.
//

import UIKit

class ResetPassworddocVC: UIViewController {
    
    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var repass: UITextField!
    @IBOutlet weak var pass: UITextField!
    @IBOutlet weak var id: UILabel!
    @IBOutlet weak var bckbtn: UIButton!
    var pid: String?
    var docpass : docpassModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("PID passed is --",pid ?? "")
        id.text = pid ?? ""
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func bckbtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitbtn(_ sender: Any) {
        postAPI()
    }
    //    func postAPI() {
    //        guard let unwrappedPid1 = pid,
    //              let password = pass.text,
    //              let repassword = repass.text else { return }
    //
    //        let formData = [
    //            "userid": unwrappedPid1,
    //            "password": password,
    //            "repassword": repassword,
    //        ]
    //
    //        APIHandler().postAPIValues(type: docpassModel.self, apiUrl: ServiceAPI.docpassURL, method: "POST", formData: formData) {
    //            [weak self] result in
    //            switch result {
    //            case .success(let data):
    //                DispatchQueue.main.async {
    //                    // Update UI based on API response here
    //                    if data.status == true {
    //                        let alert = UIAlertController(title: "Success", message: "Password updated successfully", preferredStyle: .alert)
    //                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { alert in
    //                            self?.navigationController?.popViewController(animated: true)
    //                        }))
    //                        self?.present(alert, animated: true)
    //
    //                    } else {
    //                        self?.showAlert(title: "Error", message: data.message)
    //                    }
    //                }
    //            case .failure(let error):
    //                print(error)
    //                // Handle failure scenarios (e.g., network error)
    //                self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
    //            }
    //        }
    //        }
    //    func navigateToHomePage() {
    ////        let storyboard = UIStoryboard(name: "Main", bundle: nil)
    ////        let vc = storyboard.instantiateViewController(withIdentifier: "patientLoginvc") as!patientLoginvc
    ////
    ////
    ////        navigationController?.pushViewController(vc, animated: true)
    ////        vc.pid = self.pid ?? ""
    //        navigationController?.popViewController(animated: true)
    //    }
    //    func showAlert(title: String, message: String) {
    //        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
    //        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
    //        present(alert, animated: true)
    //    }
    //}
    func postAPI() {
        guard let unwrappedPid1 = pid,
              let password = pass.text,
              let repassword = repass.text else { return }
        
        let formData = [
            "userid": unwrappedPid1,
            "password": password,
            "repassword": repassword,
        ]
        
        APIHandler().postAPIValues(type: docpassModel.self, apiUrl: ServiceAPI.docpassURL, method: "POST", formData: formData)  {
            [weak self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    // Update UI based on API response here
                    if data.status == true {
                        let alert = UIAlertController(title: "Success", message: "Password updated successfully", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { alert in
                            self?.navigationController?.popViewController(animated: true)
                        }))
                        self?.present(alert, animated: true)
                    } else {
                        self?.showAlert(title: "Error", message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                // Handle failure scenarios (e.g., network error)
                self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
            }
        }
    }
    
    func showAlert(title: String, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
}
