//
//  viewSpecificdoctorvc.swift
//  DreamMom
//
//  Created by k. Dharani on 09/03/24.
//

import UIKit

class viewSpecificdoctorvc: UIViewController {
    
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var mail: UITextField!
    @IBOutlet weak var specification: UITextField!
    
    @IBOutlet weak var bckbtn: UIButton!
    @IBOutlet weak var num: UITextField!
    @IBOutlet weak var name: UITextField!
    
    var dr_userid = Int()
    var doctorProfilemodel: doctorProfile?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDoctorProfile()
    }
    
    func fetchDoctorProfile() {
        let formData = ["userid": dr_userid]
        
        APIHandler().postAPIValues(type: doctorProfile.self, apiUrl: ServiceAPI.drProfiledisplayURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                // Check if doctorDetails is available
                if data.status {
                    let doctorDetails = data.doctorDetails
                    // Update UI with doctor details
                    DispatchQueue.main.async {
                        self?.id.text = "\(doctorDetails.drUserid)"
                        self?.name.text = doctorDetails.drName
                        self?.mail.text = doctorDetails.email
                        self?.num.text = doctorDetails.contactNo
                        self?.specification.text = doctorDetails.designation
                    }
                } else {
                    print("No doctor details found.")
                }
            case .failure(let error):
                print("Error fetching doctor details: \(error)")
            }
        }
    }

    @IBAction func bckbtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
