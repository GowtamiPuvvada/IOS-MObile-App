//
//  viewSpouseInfovc.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class viewSpouseInfovc: UIViewController {

    @IBOutlet weak var nameTEXTFEILD: UITextField!
    @IBOutlet weak var contactnumberTEXTFEILD: UITextField!
    @IBOutlet weak var bloodgroupTEXTFEILD: UITextField!
    @IBOutlet weak var weightTEXTFEILD: UITextField!
    @IBOutlet weak var heightTEXTFEILD: UITextField!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var medicalhistoryTEXTVIEW: UITextView!
    @IBOutlet weak var ageTEXTFEILD: UITextField!
    @IBOutlet weak var specificationTEXTVIEW: UITextView!
    var pid: String?
    var ViewSpouseDetails: ViewSpouseDetailsModel?
    var specifications: SpecificationsModel?
    override func viewDidLoad() {
        super.viewDidLoad()

        fetchData()
        viewdata()
    }
    
    @IBAction func bckBtn(_ sender: Any) {
        
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
//        self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
        
    }
    func fetchData() {
        guard let userId = self.pid else {
                print("User ID is nil")
                return
            }
        let formData = [
                    "userid": userId,
                ]
        APIHandler().postAPIValues(type: ViewSpouseDetailsModel.self, apiUrl: ServiceAPI.ViewSpouseURL , method: "POST", formData: formData) {
            [weak self] result in
                switch result {
                case .success(let ViewSpouseDetails):
                    self?.ViewSpouseDetails = ViewSpouseDetails
                    print("ViewSpouseDetails Response",ViewSpouseDetails)
                    // Update UI with patient details (replace these lines with your outlets)
                    DispatchQueue.main.async {
                        
                        self?.nameTEXTFEILD.text = ViewSpouseDetails.spouseDetails.name
                        self?.contactnumberTEXTFEILD.text = ViewSpouseDetails.spouseDetails.contactnumber
                        self?.bloodgroupTEXTFEILD.text = ViewSpouseDetails.spouseDetails.bloodgroup
                        self?.weightTEXTFEILD.text = ViewSpouseDetails.spouseDetails.weight
                        self?.heightTEXTFEILD.text = ViewSpouseDetails.spouseDetails.height
                        self?.medicalhistoryTEXTVIEW.text = ViewSpouseDetails.spouseDetails.medicalhistory
                        self?.ageTEXTFEILD.text = ViewSpouseDetails.spouseDetails.age
                       
                    }
                case .failure(let error):
                    print("Error fetching patient details: \(error)")
                }
            }
        }
    func viewdata() {
        guard let userId = self.pid else {
                print("User ID is nil")
                return
            }
        let formData = [
                    "userid": userId,
                ]
        APIHandler().postAPIValues(type: SpecificationsModel.self, apiUrl: ServiceAPI.specificationsURL , method: "POST", formData: formData) {
            [weak self] result in
                switch result {
                case .success(let specifications):
                    print("Received specifications response",specifications)
                    self?.specifications = specifications
                    // Update UI with patient details (replace these lines with your outlets)
                    DispatchQueue.main.async {
                        if let firstSpecification = specifications.specifications.first {
                                               self?.specificationTEXTVIEW.text = firstSpecification.specifications
                                           } else {
                                               // Handle the case when the array is empty
                                               print("Specifications array is empty")
                                           }
                    }
                case .failure(let error):
                    print("Error fetching patient details: \(error)")
                }
            }
        }
}
