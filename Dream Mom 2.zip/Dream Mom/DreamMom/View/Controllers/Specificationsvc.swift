//
//  Specificationsvc.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class Specificationsvc: UIViewController, UITextViewDelegate {

    @IBOutlet weak var specificationsTEXTVIEW: UITextView!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var savespecification: UIButton!
    var id: String?
    let placeholderText = "Please enter specifications."
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(id ?? "")
        specificationsTEXTVIEW.text = placeholderText
                specificationsTEXTVIEW.textColor = UIColor.lightGray
                specificationsTEXTVIEW.delegate = self

                

        // Do any additional setup after loading the view.
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
           // Clear placeholder if the current text is placeholder
           if textView.text == placeholderText && textView.textColor == UIColor.lightGray {
               textView.text = nil
               textView.textColor = UIColor.black // Use default or any color that signifies active text input
           }
       }

       
    func textViewDidEndEditing(_ textView: UITextView) {
           // If nothing was entered, reset to placeholder
           if textView.text.isEmpty {
               textView.text = placeholderText
               textView.textColor = UIColor.lightGray
           }
       }
    @IBAction func savespecification(_ sender: Any) {

        
        let specificationsText = specificationsTEXTVIEW.text.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if specificationsText.isEmpty || specificationsText == placeholderText {
                showAlert(title: "Missing Information", message: "Please enter specifications.")
                return
            }
            
            guard let userId = UserDefaults.standard.string(forKey: "userId") else {
                print("User ID not found")
                return
            }
            
            let formData = ["userid": userId, "Specifications": specificationsText]
            
            postPatientInfo(formData: formData) { success in
                if success {
                    DispatchQueue.main.async {
                        self.patlistvc()
                    }
                } else {
                    // Handle failure case
                    print("Failed to post patient info")
                    // Optionally, show an alert or any other UI feedback to indicate the failure
                }
            }
        }

    private func patlistvc() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "patientListvc") as? patientListvc else {
            print("Error: Unable to instantiate patientListvc")
            showAlert(title: "Error", message: "Failed to instantiate patientListvc.")
            return
        }
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(vc, animated: true)
//            self.present(vc, animated: true, completion: nil)
        }
    }

      
    
    @IBAction func bckBtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

//    func postPatientInfo(formData: [String: String], completion: @escaping (Bool) -> Void) {
//        APIHandler().postAPIValues(type: AddSpecificationsModel.self, apiUrl: ServiceAPI.addspecificationsURL, method: "POST", formData: formData) { [weak self] result in
//            guard let self = self else { return } // Use a strong self reference
//            switch result {
//            case .success(let data):
//                if data.status {
//                    DispatchQueue.main.async {
//                        // Show success message
//                        self.showAlert(title: "Success", message: "Your specifications added successfully.")
//                        print("Navigating to patientListvc...")
//                        completion(true) // Indicate success
//                    }
//                } else {
//                    // Show error message from server
//                    DispatchQueue.main.async {
//                        self.showAlert(title: "Error", message: data.message)
//                        completion(false) // Indicate failure
//                    }
//                }
//            case .failure(let error):
//                print(error.localizedDescription)
//                DispatchQueue.main.async {
//                    self.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
//                    completion(false) // Indicate failure
//                }
//            }
//        }
//    }
    func postPatientInfo(formData: [String: String], completion: @escaping (Bool) -> Void) {
        APIHandler().postAPIValues(type: AddSpecificationsModel.self, apiUrl: ServiceAPI.addspecificationsURL, method: "POST", formData: formData) { [weak self] result in
            guard let self = self else { return } // Use a strong self reference
            switch result {
            case .success(let data):
                if data.status {
                    // Show success message
                    DispatchQueue.main.async {
//                        self.showAlert(title: "Success", message: "Your specifications added successfully.")
//                        print("Navigating to patientListvc...")
                        
                        self.popUpAlert(title: "Success", message: "Your specifications added successfully.", actionTitles: ["Ok"], actionStyle: [.default], action: {Ok in
                            completion(true)
                        })
//                        DreamMom.showAlert(title: "Success", message: "Your specifications added successfully.") {
//                            completion(true) // Indicate success
//                        }
//                        self.patlistvc() // Navigation should happen after showing the success message
                    }
                } else {
                    // Show error message from server
                    DispatchQueue.main.async {
                        self.showAlert(title: "Error", message: data.message)
                    }
                    completion(false) // Indicate failure
                }
            case .failure(let error):
                print(error.localizedDescription)
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                }
                completion(false) // Indicate failure
            }
        }
    }


      
      func showAlert(title: String, message: String) {
          let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
          alert.addAction(UIAlertAction(title: "OK", style: .default))
          present(alert, animated: true)
      }
  }
    

