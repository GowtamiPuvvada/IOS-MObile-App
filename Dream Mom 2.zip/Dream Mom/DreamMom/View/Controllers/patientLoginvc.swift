//
//  patientLoginvc.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class patientLoginvc: UIViewController {

    @IBOutlet weak var bckBTN: UIButton!
    @IBOutlet weak var login: UIButton!
    var pid1 : String = ""
    
    @IBOutlet weak var passwordTEXTFEILD: UITextField!
    @IBOutlet weak var patientidTEXTFEILD: UITextField!
    @IBOutlet weak var fogetpassBTN: UIButton!
    var Patientlogin : PatientloginModel!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func login(_ sender: Any) {
        guard let userId = patientidTEXTFEILD?.text, !userId.isEmpty,
              let password = passwordTEXTFEILD?.text, !password.isEmpty else {
            print("Error: patientidTEXTFEILD or passwordTEXTFEILD is nil")
            showAlert(title: "Input Required", message: "All fields are required")
            return
        }

        
        postAPI()
    }
    func postAPI() {
        let apiURL = ServiceAPI.PatientloginURL
        print(apiURL)
        let formData = [
            "userId": patientidTEXTFEILD.text ?? "",
            "password": passwordTEXTFEILD.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: PatientloginModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                switch result {
                case .success(let data):
                    print(data)
                    self.pid1 = data.userID
                    if data.status {
                        // Navigate to home page if login is successful
                        self.navigateToHomePage()
                    } else {
                        // Show alert if the status indicates failure (e.g., incorrect password)
                        self.showAlert(title: "Login Failed", message: "Incorrect User ID or Password")
                    }
                case .failure(let error):
                    print(error)
                    // Show a general error alert
                    self.showAlert(title: "Error", message: "Please enter valid USERID or PASSWORD.")
                }
            }
        }
    }

    func navigateToHomePage() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "patienthomePagevc") as? patienthomePagevc else {
            print("Error: Unable to instantiate patienthomePagevc")
            return
        }
        vc.pid1 = self.pid1
        print(pid1)
        
        if let navigationController = self.navigationController {
            navigationController.pushViewController(vc, animated: true)
        } else {
            // If navigationController is nil, present vc modally
            present(vc, animated: true, completion: nil)
        }
    }


    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        present(alert, animated: true)
    }

    
    @IBAction func bckBTN(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "loginvc") as! loginvc
                self.navigationController?.pushViewController(vc, animated: true)
       // self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func fogetpassBTN(_ sender: Any) {
        guard let userId = patientidTEXTFEILD.text, !userId.isEmpty else {
                // Alert the user that the user ID should not be empty
                showAlert(title: "Input Required", message: "User ID should not be empty to reset password.")
                return
            }
            
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ResetPasswordVC") as! ResetPasswordVC
        vc.pid1 = self.patientidTEXTFEILD.text
        print(pid1)
        self.navigationController?.pushViewController(vc, animated: true)
      
   
    }

}

