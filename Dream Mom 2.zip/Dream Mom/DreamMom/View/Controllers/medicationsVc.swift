//
//  medicationsVc.swift
//  DreamMom
//
//  Created by SAIL on 21/11/23.
//

import UIKit

class medicationsVc: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    
    
    @IBOutlet weak var nameLbl: UILabel!
    
    
    @IBOutlet weak var ageLbl: UILabel!
    @IBOutlet weak var timeTEXTFEILD: UITextField!
    
    @IBOutlet weak var quantityTEXTFEILD: UITextField!
    
    @IBOutlet weak var medicineNameTEXTFEILD: UITextField!
    @IBOutlet weak var dateTEXTFEILD: UITextField!
    
    @IBOutlet weak var whenTextFeild: UITextField!
    
    
    
    
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var bckBtn: UIButton!
    var pid: String?
    var AddMedications: AddMedicationsModel?
    let placeholderText = "Enter your text here..."
    let placeholderTextColor = UIColor.lightGray
    let datePicker = UIDatePicker()
    let calendar = Calendar.current
    let currentDate = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        datePicker.datePickerMode = .date
              datePicker.locale = Locale(identifier: "en_US")
              datePicker.minimumDate = currentDate
        datePicker.date = currentDate

              // Assuming this function sets the input view to a date picker
              self.dateTEXTFEILD.setInputViewDatePicker(target: self, selector: #selector(tapDone))
        // Set the text field to the current date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            self.dateTEXTFEILD.text = dateFormatter.string(from: currentDate)

              mainView.clipsToBounds = true
              mainView.layer.cornerRadius = 50
              mainView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]

              topView.layer.cornerRadius = 15
    }
    @objc func tapDone() {
           if let picker = dateTEXTFEILD.inputView as? UIDatePicker {
               let dateformatter = DateFormatter()
               dateformatter.dateFormat = "yyyy-MM-dd" // Change the date format here
               self.dateTEXTFEILD.text = dateformatter.string(from: picker.date)
           }
           self.dateTEXTFEILD.resignFirstResponder()
       }
    
    @IBAction func backBtnTapped(_ sender: Any) {
    }
    
    
    @IBAction func nextBtnTapped(_ sender: Any) {
            guard let userId = pid,
                  let medicineName = medicineNameTEXTFEILD.text, !medicineName.isEmpty,
                  let quantity = quantityTEXTFEILD.text, !quantity.isEmpty,
                  let time = timeTEXTFEILD.text, !time.isEmpty,
                  let when = whenTextFeild.text, !when.isEmpty else {
                showAlert(title: "Error", message: "All fields are required")
                return
            }

            let formData: [String: String] = [
                "userid": userId,
                "medicinename": medicineName,
                "quantity": quantity,
                "time": time,
                "when": when
            ]

            APIHandler().postAPIValues(type: AddMedicationsModel.self, apiUrl: ServiceAPI.AddMedicationsURL, method: "POST", formData: formData) { [weak self] result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        if data.status {
                            let alert = UIAlertController(title: "Success", message: "Medication saved successfully", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                                self?.navigationController?.popViewController(animated: true)
                            })
                            self?.present(alert, animated: true)
                        } else {
                            self?.showAlert(title: "Error", message: data.message)
                        }
                    }
                case .failure(let error):
                    print(error)
                    self?.showAlert(title: "Error", message: "Failed to save medication. Please try again.")
                }
            }
        }

        func showAlert(title: String, message: String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true)
        }

       
        
    @IBAction func bckbtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    
}
