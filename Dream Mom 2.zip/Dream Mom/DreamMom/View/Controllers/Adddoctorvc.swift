import UIKit

class Adddoctorvc: UIViewController {
    
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var doctoridTextFeild: UITextField!
    @IBOutlet weak var drNameTextFeild: UITextField!
    @IBOutlet weak var submitbtn: UIButton!
    @IBOutlet weak var specificationTextfeild: UITextField!
    @IBOutlet weak var phonenumberTextFeild: UITextField!
    @IBOutlet weak var emailTextFeild: UITextField!
    
    var dr_userid: Int?
    var adddoctoedetails: adddoctoedetailsModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the text field's text to the dr_userid
        if let userid = dr_userid {
            doctoridTextFeild.text = String(userid)
        }
    }
    
    @IBAction func bckBtn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitbtn(_ sender: Any) {
        signupAPI()
    }
    
    func signupAPI() {
        // Check if all fields are filled
        guard let name = drNameTextFeild.text, !name.isEmpty,
              let designation = specificationTextfeild.text, !designation.isEmpty,
              let email = emailTextFeild.text, !email.isEmpty,
              let number = phonenumberTextFeild.text, !number.isEmpty else {
            showAlert(title: "Alert", message: "All fields are required.")
            return
        }
        
        // Check email format
        guard email.lowercased().hasSuffix("@gmail.com") else {
            showAlert(title: "Alert", message: "Incorrect email format. Must end with @gmail.com.")
            return
        }
        
        // Check phone number format
        guard number.count == 10, number.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil else {
            showAlert(title: "Alert", message: "Incorrect phone number format. Must contain 10 digits only.")
            return
        }
        
        // Form data for API request
        let formData: [String: String] = [
            "dr_userid": String(dr_userid ?? 0),
            "dr_name": name,
            "designation": designation,
            "email": email,
            "contact_no": number
        ]
        
        // Call API to add doctor details
        APIHandler().postAPIValues(type: adddoctoedetailsModel.self, apiUrl: ServiceAPI.adddocterdetailsURL, method: "POST", formData: formData) { [self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    print(data.message)
                    // Show alert on successful addition
                    showAlert(title: "Success", message: "Doctor details added successfully.") { _ in
                        // Navigate to another view controller
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyBoard.instantiateViewController(withIdentifier: "AddAdminvc") as! AddAdminvc
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                    
                case .failure(let error):
                    print("Network Error: \(error)")
                    // Show error alert
                    showAlert(title: "Warning", message: "Something went wrong. Please try again later.")
                }
            }
        }
    }
    
    func showAlert(title: String, message: String, completion: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: completion))
        present(alert, animated: true, completion: nil)
    }
}
