//
//  medicationspvc.swift
//  DreamMom
//
//  Created by SAIL on 22/11/23.
//

import UIKit

class medicationspvc: UIViewController {
   
    @IBOutlet weak var bckBTN: UIButton!
    
    @IBOutlet weak var medicineTv: UITableView!
    
    var pid1: String?
          
    
    var madicineName = ["dolo","polo"]
    var quantity = ["5","6"]
    var time = ["mrng","noon"]
    var ViewMedications : ViewMedicationsModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
//        medicineTv.register(UINib.init(nibName: "MedicineForPatientCell", bundle: nil), forCellReuseIdentifier: "cell")
//        medicineTv.reloadData()
//        medicineTv.delegate = self
//        medicineTv.dataSource = self
//
//        viewData()
        medicineTv.register(UINib.init(nibName: "medicalcell", bundle: nil), forCellReuseIdentifier: "medicalcell")
        medicineTv.reloadData()
        medicineTv.delegate = self
        medicineTv.dataSource = self
        viewData()
    }
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async { [self] in
           
            viewData()
        }
      
    }
//    func viewData() {
//
//        guard let userId = pid1 else {
//            print("User ID is nil")
//            return
//        }
//        let formData = [
//                    "userid": userId,
//                ]
//
//        APIHandler().postAPIValues(type: ViewMedicationsModel.self, apiUrl: ServiceAPI.ViewMedicationsURL , method: "POST", formData:formData) {
//            [weak self] result in
//
//            switch result {
//            case .success(let data):
//
//                if data.status == true {
//                    DispatchQueue.main.async {
//                    self?.ViewMedications = data
//                    self?.medicineTv.reloadData()
//                    print(data)
//                    }
//                } else {
//
//                    DispatchQueue.main.async {
//                    //self?.showAlert(title: "Error", message: "")
//                    }
//
//                }
//            case .failure(let error):
//                print(error)
//                // Handle failure scenarios (e.g., network error)
////self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
//            }
//        }
//    }
    func viewData() {
    
    guard let userId = pid1 else {
        print("User ID is nil")
        return
    }
    let formData = [
                "userid": userId,
            ]
        
    APIHandler().postAPIValues(type: ViewMedicationsModel.self, apiUrl: ServiceAPI.ViewMedicationsURL , method: "POST", formData:formData) {
        [weak self] result in
      
        switch result {
        case .success(let data):
            
            if data.status == true {
                DispatchQueue.main.async {
                self?.ViewMedications = data
                self?.medicineTv.reloadData()
                print(data)
                }
            } else {
               
                DispatchQueue.main.async {
                //self?.showAlert(title: "Error", message: "")
                }
           
            }
        case .failure(let error):
            print(error)
            // Handle failure scenarios (e.g., network error)
//self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
        }
    }
}

    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return madicineName.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! MedicineForPatientCell
////        cell.translatesAutoresizingMaskIntoConstraints = true
////
////
////        if indexPath.row < madicineName.count {
////            cell.medicinenameLbl.text = madicineName[indexPath.row]
////        }
////        if indexPath.row < quantity.count {
////            cell.quantityLbl.text = quantity[indexPath.row]
////        }
////        if indexPath.row < time.count {
////            cell.timeLbl.text = time[indexPath.row]
////        }
//
//        return cell
//    }
//
//
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 200.0
//    }
    
    @IBAction func bckBTN(_ sender: Any) {
//        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier:"patienthomePagevc") as! patienthomePagevc
//        vc.pid1 = self.pid1!
//        self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
    }
    
  
}
extension medicationspvc : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ViewMedications?.patientDetails.count ?? 0
   }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"medicalcell", for: indexPath) as! medicalcell
        cell.medicinename.text =  ViewMedications?.patientDetails[indexPath.row].medicineName
        cell.medicinequantity.text =  ViewMedications?.patientDetails[indexPath.row].time
        cell.timing.text =  ViewMedications?.patientDetails[indexPath.row].quantity
        cell.date.text =  ViewMedications?.patientDetails[indexPath.row].date
        cell.when.text =  ViewMedications?.patientDetails[indexPath.row].when
              return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    
}
