import UIKit

class patienthomePagevc: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var profile: UIButton!
    @IBOutlet weak var logupdate: UIButton!
    @IBOutlet weak var viewreports: UIButton!
    @IBOutlet weak var advices: UIButton!
    @IBOutlet weak var graphs: UIButton!
    @IBOutlet weak var medications: UIButton!
    @IBOutlet weak var remainingdaysLBL: UILabel!
    var selectedImages: [UIImage] = []
    var body = Data()
    let imagePicker = UIImagePickerController()
    var monthday: monthdayModel?
    var incrementdate: incrementdateModel?
    
    
    var pid1 : String = " "
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
     //   fetchData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Fetch data and update UI every time the view appears
        fetchData { differenceInDays in
            if let difference = differenceInDays {
                // Update UI with the difference in days
                DispatchQueue.main.async {
                    self.remainingdaysLBL.text = "Day \(difference) "
                }
            } else {
                // Handle case where data could not be fetched or cycleupdate array is empty
                DispatchQueue.main.async {
                    self.remainingdaysLBL.text = "Error fetching data"
                }
            }
        }
    }

    func fetchData(completion: @escaping (Int?) -> Void) {
        let userId = self.pid1 // Assuming pid1 is a String representing the user ID

        let formData = [
            "userid": userId,
        ]
        
        APIHandler().postAPIValues(type: incrementdateModel.self, apiUrl: ServiceAPI.incerementdateURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let namelist):
                // Check if cycleupdate array is not empty
                if let firstCycleUpdate = namelist.cycleupdate.first {
                    // Convert the date obtained from API to a Date object
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    if let cycleDate = dateFormatter.date(from: firstCycleUpdate.date) {
                        // Calculate the difference in days between current date and cycleDate
                        let currentDate = Date()
                        let calendar = Calendar.current
                        let dateComponents = calendar.dateComponents([.day], from: cycleDate, to: currentDate)
                        let differenceInDays = dateComponents.day
                        completion(differenceInDays)
                        return
                    } else {
                        print("Error: Unable to convert date from API to Date object")
                    }
                } else {
                    // Handle the case where cycleupdate array is empty
                    print("Cycleupdate array is empty")
                }
            case .failure(let error):
                print("Error fetching patient details: \(error)")
            }
            
            // If there was an error or cycleupdate array was empty, return nil
            completion(nil)
        }
    }


//    func dateFromString(_ dateString: String, withFormat format: String = "yyyy-MM-dd") -> Date? {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = format
//        dateFormatter.timeZone = TimeZone(identifier: "UTC") // Adjust if necessary
//
//        if let date = dateFormatter.date(from: dateString) {
//            print("Converted date string: \(dateString) to date: \(date)")
//            return date
//        } else {
//            print("Failed to convert date string: \(dateString) with format: \(format)")
//            return nil
//        }
//    }


//
//        func daysBetween(start: Date, end: Date) -> Int {
//            let calendar = Calendar.current
//            let startDay = calendar.startOfDay(for: start)
//            let endDay = calendar.startOfDay(for: end)
//            let components = calendar.dateComponents([.day], from: startDay, to: endDay)
//            return components.day ?? 0
//        }

   
    
    
    @IBAction func addreportbtn(_ sender: Any) {
        presentImagePicker()
    }
    
    func presentImagePicker() {
            let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                self.openCamera()
            }))
            alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                self.openGallery()
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                selectedImages.append(pickedImage)
                GetAPI()
            }

            picker.dismiss(animated: true, completion: nil)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }

    @IBAction func whatsbtn(_ sender: Any) {
        let phoneNumber = "1234567890"

            if let whatsappURL = URL(string: "https://api.whatsapp.com/send?phone=\(phoneNumber)") {
                if UIApplication.shared.canOpenURL(whatsappURL) {
                    UIApplication.shared.open(whatsappURL, options: [:], completionHandler: nil)
                } else {
                    // WhatsApp is not installed, display an alert or take appropriate action
                    let alertController = UIAlertController(title: "Error", message: "WhatsApp is not installed on your device.", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(okAction)
                    present(alertController, animated: true, completion: nil)
                }
            }
    }
    
    
    @IBAction func profile(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientProfilevc") as! patientProfilevc
        vc.pid1 = self.pid1
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func logupdate(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Cycleupdatevc") as! Cycleupdatevc
        vc.pid1 = self.pid1
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func viewreports(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Viewreportspvc") as! Viewreportspvc
        vc.pid1 = self.pid1
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func advices(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "viewadvicepvc") as! viewadvicepvc
        vc.pid1 = self.pid1
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    
    @IBAction func graphs(_ sender: Any) {
        
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "Graphspvc") as! Graphspvc
        vc.pid1 = self.pid1
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func medications(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "medicationspvc") as! medicationspvc
        vc.pid1 = self.pid1
        self.navigationController?.pushViewController(vc, animated: true)
        
    }


}
extension patienthomePagevc {
    func GetAPI() {
        let userId = self.pid1

        let formData: [String: String] = [
            "Userid": pid1,
        ]
        let apiURL = ServiceAPI.uploadimgURL
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()

        for (key, value) in formData {
            guard let valueData = "\(value)\r\n".data(using: .utf8) else {
                print("Failed to convert value to data for key: \(key)")
                return
            }
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append(valueData)
        }

        for (index, image) in selectedImages.enumerated() {
            let fieldName = "image"
            let fileName = "image\(index).jpg"
            if let imageData = image.jpegData(compressionQuality: 0.8) {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
                body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
                body.append(imageData)
                body.append("\r\n".data(using: .utf8)!)
            }
        }

        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")

                    
                    // Check the server response and show an alert
                    if let responseString = String(data: data, encoding: .utf8),
                       responseString.contains("User registration successful") {
                        print("Image uploaded successfully")
                        DispatchQueue.main.async {
                            self.showUploadSuccessAlert()
                        }
                    } else {
                        print("Image upload failed")
                        DispatchQueue.main.async {
                            self.showUploadFailureAlert()
                        }
                    }
                }
            }
        }
        print("Executing URLSession Task...")
        task.resume()
    }
    private func appendToBody(_ string: String) {
           if let data = string.data(using: .utf8) {
               body.append(data)
           }
       }

        func showUploadSuccessAlert() {
            let alert = UIAlertController(title: "Upload Successful", message: "Your image was uploaded successfully.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }

        func showUploadFailureAlert() {
            let alert = UIAlertController(title: "Upload Failed", message: "There was an error uploading your image. Please try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
