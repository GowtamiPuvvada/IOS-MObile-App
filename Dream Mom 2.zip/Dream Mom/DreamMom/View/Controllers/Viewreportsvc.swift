//
//  Viewreportsvc.swift
//  DreamMom
//
//  Created by SAIL on 21/11/23.
//

import UIKit

class Viewreportsvc: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var reportstableview: UITableView!
    var imageResponse : ViewimageModel?
    var pid: String?
    var imagenamearray = ["image1","image2"]
    var imagesize = ["123k","986kb"]
    var date = ["23/9/2023","23/4/2003"]
  //  var imageModels: [Datum1] = []
    var reportList : [String] = []
    var dateList : [String] = []
    var dayList: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        reportstableview.register(UINib.init(nibName: "imagestv", bundle: nil), forCellReuseIdentifier: "imagestv")
        reportstableview.dataSource = self
        reportstableview.delegate = self
        reportstableview.reloadData()
        fetchImageModels()
    }

    func fetchImageModels() {
        let apiURL = "\(ServiceAPI.viewimgURL)?userid=\(pid ?? "")" // Replace
        
        APIHandler().getAPIValues(type: ViewimageModel.self, apiUrl: apiURL, method: "GET") { [self] result in
            switch result {
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self.reportList = data.images
                    self.dateList = data.date
                    self.dayList = data.day
                    self.reportstableview.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    // Handle error response
                    // Display an error message or take appropriate action
                }
            }
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reportList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"imagestv", for: indexPath) as! imagestv
        DispatchQueue.main.async { [self] in
         
        if indexPath.row < reportList.count {
            let imageURLString = reportList[indexPath.row]
            let date = reportList[indexPath.row]
            let day = dayList[indexPath.row]
            if let imageURL = URL(string: imageURLString),
               let imageData = try? Data(contentsOf: imageURL),
               let image = UIImage(data: imageData) {
                cell.imagepdf.image = image
                cell.imagename.text = imageData.description
                cell.date.text = dateList[indexPath.row]
//                cell.date.text = "Date: \(date)" // Displaying date
                cell.day.text = dayList[indexPath.row]// Displaying day
            }
//            cell.imagename.text = "Image \(indexPath.row + 1)"
           
//            cell.date.text = "date\(date)"
        
            // cell.imagesize.text = "Size: \(imageData.count) bytes"  // Uncomment if neehttp://192.168.193.53/infertility/videos/image0.jpgded
//            cell.date.text = "Date: \(Date())"
        }
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier:"Addreportsnewvc") as! Addreportsnewvc
        vc.pid = self.pid
        if indexPath.row < reportList.count {
               let imageURLString = reportList[indexPath.row]
               if let imageURL = URL(string: imageURLString),
                  let imageData = try? Data(contentsOf: imageURL),
                  let image = UIImage(data: imageData) {
                   vc.selectedImage = image
               }
           }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

    @IBAction func bckBtn(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier:"ViewPatientvc") as! ViewPatientvc
        vc.pid = self.pid
        self.navigationController?.pushViewController(vc, animated: true)
     //   navigationController?.popViewController(animated: true)
    }
    

}
