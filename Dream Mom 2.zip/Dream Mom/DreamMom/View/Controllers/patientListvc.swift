//
//  patientListvc.swift
//  DreamMom
//
//  Created by SAIL L1 on 17/11/23.
//

import UIKit

class patientListvc: UIViewController  {
    
 
    @IBOutlet weak var searchbar: UISearchBar!
    
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var patientlist: UITableView!
   
    var Searchbar:SearchbarModel?
    var searchOption = false
    var viewPatientList:ViewPatientListModel?


    var id: String?{
        didSet{
            fetchData()
           
        }
    }
    override func viewDidLoad() {
            super.viewDidLoad()
            self.navigationController?.isNavigationBarHidden = true
            patientlist.delegate = self
            patientlist.dataSource = self
            searchbar.delegate = self // Corrected: from 'searchBar' to 'searchbar' to match IBOutlet name
            
            fetchData()
        }
    
    func fetchData() {
        searchOption = false
        APIHandler().postAPIValues(type: ViewPatientListModel.self, apiUrl: ServiceAPI.ViewPatientListURL, method: "POST", formData: [:]) { [weak self] result in
            switch result {
            case .success(let data):
                if data.status == true {
                    DispatchQueue.main.async {
                        self?.viewPatientList = data
                        self?.patientlist.reloadData()
                        print("Fetch Data Success:", data)
                    }
                } else {
                    DispatchQueue.main.async {
                        // Handle the case where data.status is false
                    }
                }
            case .failure(let error):
                print("Fetch Data Error:", error)
                // Handle failure scenarios (e.g., network error)
                // self?.showAlert(title: "Error", message: "Failed to fetch data. Please try again.")
            }
        }
    }

  
    func searchApi(searchText: String) {
        if searchText.isEmpty {
                // If search text is empty, reload all data
                fetchData()
            } else {
        var formData: [String: String] = [:]

        // Check if searchText is a number (assuming user ID is numeric)
        if let userId = Int(searchText) {
            formData["userid"] = "\(userId)"
        } else {
            // If searchText is not a number, treat it as a name
            formData["name"] = searchText
        }
        searchOption = true
            APIHandler().postAPIValues(type: SearchbarModel.self, apiUrl: ServiceAPI.searchURL, method: "POST", formData: formData) { [weak self] result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        self?.Searchbar = response
                        self?.patientlist.reloadData()
                        print("Search API Success:", response)
                    }

                case .failure(let error):
                    DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Alert", message: "The Patient Does not Exist", preferredStyle: .alert)
                        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(cancelAction)
                        self?.present(alertController, animated: false, completion: nil)
                        print("Search API Error:", error)
                    }
                }
                }
            }
        }
    
    
    
//    @IBAction func seatchTapped(_ sender: Any) {
//        print("Search button tapped")
//           guard let searchText = searchBar.text else {
////               , !searchText.isEmpty
//               // Show an alert if the search bar is empty
//               return
//           }
//           searchApi(searchText: searchText)
//       }
    @IBAction func bckBtn(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "homePage") as! homePage

                self.navigationController?.pushViewController(vc, animated: true)
       // self.navigationController?.popViewController(animated: true)
    }
    

}
extension patientListvc: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder() // Hide the keyboard
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Debouncing or rate limiting is recommended here
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(self.reload(_:)), object: searchBar)
        self.perform(#selector(self.reload(_:)), with: searchBar, afterDelay: 0.5) // 0.5 seconds delay
    }
    
    @objc func reload(_ searchBar: UISearchBar) {
        guard let searchText = searchBar.text else { return }
        if searchText.isEmpty {
            fetchData() // Load all data if search text is cleared
        } else {
            searchApi(searchText: searchText) // Perform search with the current input
        }
    }
}



extension patientListvc: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchOption ? Searchbar?.search.count ?? 0 : viewPatientList?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "list", for: indexPath) as? list else {
            return UITableViewCell()
        }
        
        if searchOption {
            if let searchResult = Searchbar?.search[indexPath.row] {
                cell.patientname.text = searchResult.name
                cell.patientnum.text = "\(searchResult.userid)"
            }
        } else {
            if let patient = viewPatientList?.data?[indexPath.row] {
                cell.patientname.text = patient.name
                cell.patientnum.text = "\(patient.userid)"
            }
        }

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
        
        if searchOption {
            // Pass the selected user ID for the searched user
            if let userId = Searchbar?.search[indexPath.row].userid {
                let ids = String(userId)
                print("Selected patient ID -->", ids)
                vc.pid = ids
            }
        } else {
            // Pass the selected user ID for all users
            if let userId = viewPatientList?.data?[indexPath.row].userid {
                let ids = String(userId)
                print("Selected patient ID -->", ids)
                vc.pid = ids
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }

    
}
extension patientListvc: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
            if let searchText = textField.text {
                searchApi(searchText: searchText)
            }
            return true
    }
}
