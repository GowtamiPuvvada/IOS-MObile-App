import UIKit

class Cycleupdatevc: UIViewController {

    @IBOutlet weak var dateLbl: UITextField!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var okBtn: UIButton!
    var pid1: String?
    var cycleupdateP: cycleupdatePModel?

    let datePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()

        configureDatePicker()
    }

    func configureDatePicker() {
        datePicker.datePickerMode = .date
        dateLbl.inputView = datePicker

        // Create a toolbar with a "Done" button
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))
        toolbar.setItems([doneButton], animated: false)

        dateLbl.inputAccessoryView = toolbar

        datePicker.addTarget(self, action: #selector(datePickerValueChanged), for: .valueChanged)
    }

    @objc func doneButtonTapped() {
        dateLbl.resignFirstResponder() // Dismiss the date picker when "Done" is tapped
    }
    @objc func datePickerValueChanged() {
        let selectedDate = datePicker.date
        let currentDate = Date()

        // Check if the selected date is in the future
        if selectedDate > currentDate {
            // The selected date is in the future, you can handle this as per your requirement
            // For example, preventing the change and showing an alert
            datePicker.date = currentDate
            showAlert(title: "Invalid Date", message: "Please select a date in the past or today.")
        } else {
            // The selected date is valid, update the text field
            let dateFormatter = DateFormatter()
            dateFormatter.timeZone = TimeZone.current
            dateFormatter.dateFormat = "yyyy/MM/dd"
            self.dateLbl.text = dateFormatter.string(from: selectedDate)
        }
    }

    


    @IBAction func bckbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func okbtn(_ sender: Any) {
//        guard dateLbl.text == nil else {
//            showAlert(title: "Date", message: "Choose the Date")
//            return
//        }
        guard let userId = self.pid1 else {
            self.showAlert(title: "Error", message: "User ID is required")
            return
        }
        guard let selectedDate = dateLbl.text, !selectedDate.isEmpty else {
               showAlert(title: "Date", message: "Choose the Date")
               return
           }

        // Use the date directly, as it's not an optional
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy/MM/dd" // Make sure this format matches your backend's expected format
        let formattedDate = dateFormatter.string(from: self.datePicker.date)

        let formData: [String: String] = [
            "userid": userId,
            "updatedate": formattedDate
        ]

        APIHandler().postAPIValues(type: cycleupdatePModel.self, apiUrl: ServiceAPI.cycleupdatePURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    if data.status == true {
                        let alert = UIAlertController(title: "Success", message: "Cycle updated successfully", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                            self?.navigationController?.popViewController(animated: true)
                        })
                        self?.present(alert, animated: true, completion: nil)
                    } else {
                        self?.showAlert(title: "Error", message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                self?.showAlert(title: "Error", message: "Failed to update cycle. Please try again.")
            }
        }
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
}
