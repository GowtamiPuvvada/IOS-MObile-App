//
//  imagesopenpvc.swift
//  DreamMom
//
//  Created by SAIL on 28/11/23.
//

import UIKit

class imagesopenpvc: UIViewController {

    @IBOutlet weak var bckBTN: UIButton!
    @IBOutlet weak var imageIMAGEVIEW: UIImageView!
    var pid1: String?
    var selectedImage: UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()

        if let image = selectedImage {
                    imageIMAGEVIEW.image = image
                }
    }
    

    @IBAction func bckBTN(_ sender: Any) {
//        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier:"Viewreportspvc") as! Viewreportspvc
//        vc.pid1 = self.pid1!
//        self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
    }
    
}
