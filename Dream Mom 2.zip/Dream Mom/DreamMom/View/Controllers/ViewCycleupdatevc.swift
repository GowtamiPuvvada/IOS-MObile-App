import UIKit

class ViewCycleupdatevc: UIViewController {
    
    @IBOutlet weak var viewdateTEXTFEILD: UILabel!
    @IBOutlet weak var back: UIButton!
    var pid: String?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
    }
    
    func fetchData() {
        guard let userId = self.pid else {
            print("Error: No user ID provided")
            updateUI(with: "Error fetching data")
            return
        }
        
        let formData = ["userid": userId]
        
        APIHandler().postAPIValues(type: incrementdateModel.self, apiUrl: ServiceAPI.incerementdateURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let namelist):
                if let differenceInDays = self?.calculateDifferenceInDays(from: namelist) {
                    self?.updateUI(with: "Day \(differenceInDays)")
                } else {
                    self?.updateUI(with: "Error fetching data")
                }
            case .failure(let error):
                print("Error fetching patient details: \(error)")
                self?.updateUI(with: "Error fetching data")
            }
        }
    }
    
    private func calculateDifferenceInDays(from namelist: incrementdateModel) -> Int? {
        guard let firstCycleUpdate = namelist.cycleupdate.first else {
            print("Cycleupdate array is empty")
            return nil
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        guard let cycleDate = dateFormatter.date(from: firstCycleUpdate.date) else {
            print("Error: Unable to convert date from API to Date object")
            return nil
        }
        
        let currentDate = Date()
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.day], from: cycleDate, to: currentDate)
        return dateComponents.day
    }
    
    func updateUI(with text: String) {
        DispatchQueue.main.async {
            self.viewdateTEXTFEILD.text = text
        }
    }
    
    @IBAction func button(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
