// doctorLoginvc.swift

import UIKit

class doctorLoginvc: UIViewController {

    @IBOutlet weak var bckBTN: UIButton!
    @IBOutlet weak var userIDTextfield: UITextField!
    @IBOutlet weak var LogInButton: UIButton!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    var drLoginData: drloginModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func Login(_ sender: Any) {
        if userIDTextfield.text?.isEmpty == true || passwordTextfield.text?.isEmpty == true {
            showAlert(title: "Alert", message: "Enter UserID & password")
        } else {
            postAPI()
        }
    }
    
    func postAPI() {
        let apiURL = ServiceAPI.LogInURL
        let formData = [
            "userId": userIDTextfield.text ?? "",
            "password": passwordTextfield.text ?? ""
        ]
        
        APIHandler().postAPIValues(type: drloginModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                switch result {
                case .success(let data):
                    print(data)
                    if data.status {
                        self.navigateToHomePage(userID: self.userIDTextfield.text ?? "")
                    } else {
                        self.showAlert(title: "Incorrect", message: "Incorrect User ID & Password")
                    }
                case .failure(let error):
                    print(error)
                    self.showAlert(title: "Warning", message: "Something went wrong")
                }
            }
        }
    }
    
    func navigateToHomePage(userID: String) {
        if let userIDInt = Int(userID) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let homePageVC = storyboard.instantiateViewController(withIdentifier: "homePage") as! homePage
            homePageVC.userID = userIDInt
            print(userIDInt)
            navigationController?.pushViewController(homePageVC, animated: true)
        } else {
            print("Error: Unable to convert userID to Int")
            // Handle the error appropriately
        }
    }
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        present(alert, animated: true)
    }
    
    @IBAction func bckBTN(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "loginvc") as! loginvc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func frgbtn(_ sender: Any) {
        guard let userId = userIDTextfield.text, !userId.isEmpty else {
                // Alert the user that the user ID should not be empty
                showAlert(title: "Input Required", message: "User ID should not be empty to reset password.")
                return
            }
            
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ResetPassworddocVC") as! ResetPassworddocVC
        vc.pid = self.userIDTextfield.text
        self.navigationController?.pushViewController(vc, animated: true)
      
    }
}
