//
//  loginvc.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class loginvc: UIViewController {

    @IBOutlet weak var doctorlogin: UIButton!
    
    @IBOutlet weak var adminlogin: UIButton!
    @IBOutlet weak var patientlogin: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func adminlogin(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "AdminVc") as! AdminVc
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func doctorlogin(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "doctorLoginvc") as! doctorLoginvc
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func patientlogin(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "patientLoginvc") as! patientLoginvc
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
