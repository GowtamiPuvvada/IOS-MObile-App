//
//  medicalhistoryvc.swift
//  DreamMom
//
//  Created by k. Dharani on 24/11/23.
//

import UIKit

class medicalhistoryvc: UIViewController {
    
    
    @IBOutlet weak var status: UITableView!
    
    var pid: String?
    var ViewStatus : ViewStatusModel?
    
    @IBOutlet weak var bckBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        status.register(UINib.init(nibName: "StatusCell", bundle: nil), forCellReuseIdentifier: "cell")
        status.dataSource = self
        status.delegate = self
        status.reloadData()
        fetchData()
        
    }
    func fetchData() {
        
        guard let userId = pid else {
            print("User ID is nil")
            return
        }
        let formData = [
                    "userid": userId,
                ]
            
        APIHandler().postAPIValues(type: ViewStatusModel.self, apiUrl: ServiceAPI.ViewStatusModelURL , method: "POST", formData:formData) {
            [weak self] result in
            switch result {
            case .success(let data):
                
                if data.status == true {
                    DispatchQueue.main.async {
                    self?.ViewStatus = data
                    self?.status.reloadData()
                    print(data)
                    }
                } else {
                   
                    DispatchQueue.main.async {
                    //self?.showAlert(title: "Error", message: "")
                    }
               
                }
            case .failure(let error):
                print(error)
                // Handle failure scenarios (e.g., network error)
//self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
            }
        }
    }
    
    
    @IBAction func bckbtn(_ sender: Any) {
//        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
//        vc.pid = self.pid
//      self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
    }
}
    
extension medicalhistoryvc: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return ViewStatus?.viewreport.count ?? 0
    }
    
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell", for: indexPath) as! StatusCell
        
        cell.day.text = ViewStatus?.viewreport[indexPath.row].day
        cell.date.text = ViewStatus?.viewreport[indexPath.row].date
        cell.lo.text = ViewStatus?.viewreport[indexPath.row].leftovery
        cell.ro.text = ViewStatus?.viewreport[indexPath.row].rightovery
        
       
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    
    

}
