//
//  imagesopenvc.swift
//  DreamMom
//
//  Created by SAIL on 23/11/23.
//

import UIKit

class imagesopenvc: UIViewController {
    var destinationVC: Addreportsvc?


    @IBOutlet weak var imageIMAGEVIEW: UIImageView!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var addreports: UIButton!
    var pid: String?
    var selectedImage: UIImage?
    override func viewDidLoad() {
        super.viewDidLoad()
        if let image = selectedImage {
                    imageIMAGEVIEW.image = image
                }

        
    }
    
    
    @IBAction func addreports(_ sender: Any) {
           // Check if destinationVC already exists in the navigation stack
           if let destinationVC = destinationViewControllerOfType(Addreportsvc.self) {
               // If it exists, pop back to it
               navigationController?.popToViewController(destinationVC, animated: true)
           } else {
               // Otherwise, instantiate and push it onto the stack
               let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
               let vc = storyBoard.instantiateViewController(withIdentifier: "Addreportsvc") as! Addreportsvc
               
               // Save the selected image and any other necessary data
               vc.selectedImage = selectedImage
               vc.pid = self.pid
               
               // Navigate to the second view controller
               self.navigationController?.pushViewController(vc, animated: true)
           }
       }
    
    @IBAction func bckBtn(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "Viewreportsvc") as! Viewreportsvc
        vc.pid = self.pid
                self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func destinationViewControllerOfType<T: UIViewController>(_ type: T.Type) -> T? {
            if let viewControllers = navigationController?.viewControllers {
                for viewController in viewControllers {
                    if let specificViewController = viewController as? T {
                        return specificViewController
                    }
                }
            }
            return nil
        }
    }
