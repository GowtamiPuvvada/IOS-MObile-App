//
//  ViewPatientvc.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class ViewPatientvc: UIViewController, SlideViewDelegate{
    
//    var profile: ViewPatientModel?
   
    
    @IBOutlet weak var nameLBL: UILabel!
   // @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var bctBtn: UIButton!
    
    
    @IBOutlet weak var patientidLBL: UILabel!
    @IBOutlet weak var contactnumberLBL: UILabel!
    
    @IBOutlet weak var ageLBL: UILabel!
    
    @IBOutlet weak var genderLBL: UILabel!
    @IBOutlet weak var heightLBL: UILabel!
    
    @IBOutlet weak var weightLBL: UILabel!
    @IBOutlet weak var medicalhistoryTEXTVIEW: UITextView!
    
    @IBOutlet weak var addressLBL: UILabel!
    @IBOutlet weak var marrigeyearLBL: UILabel!
    
    
    @IBOutlet weak var bloodgroupLBL: UILabel!
    
    @IBOutlet weak var medicaltv : UITableView! {
        didSet {
            fetchData()
            
        }
    }
    var madicineName = ["dolo","polo"]
    var quantity = ["5","6"]
    var time = ["mrng","noon"]
    
    var pid: String?
    
    var viewPatient : ViewPatientModel?
    var ViewMedications : ViewMedicationsModel?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        medicaltv.dataSource = self
        medicaltv.delegate = self
        medicaltv.register(UINib(nibName: "medicalcell", bundle: nil), forCellReuseIdentifier: "medicalcell")
        
       
        // Fetch data and update the view
        fetchData()
        viewData()
    }

    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async { [self] in
            fetchData()
            viewData()
        }
      
    }
    func viewData() {
        
        guard let userId = pid else {
            print("User ID is nil")
            return
        }
        let formData = [
                    "userid": userId,
                ]
            
        APIHandler().postAPIValues(type: ViewMedicationsModel.self, apiUrl: ServiceAPI.ViewMedicationsURL , method: "POST", formData:formData) {
            [weak self] result in
          
            switch result {
            case .success(let data):
                
                if data.status == true {
                    DispatchQueue.main.async {
                    self?.ViewMedications = data
                    self?.medicaltv.reloadData()
                    print(data)
                    }
                } else {
                   
                    DispatchQueue.main.async {
                    //self?.showAlert(title: "Error", message: "")
                    }
               
                }
            case .failure(let error):
                print(error)
                // Handle failure scenarios (e.g., network error)
//self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
            }
        }
    }
    
    

//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 2
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier:"medicalcell", for: indexPath) as! medicalcell
//        cell.medicinename.text = madicineName[indexPath.row]
//        cell.medicinequantity.text = quantity[indexPath.row]
//        cell.timing.text = time[indexPath.row]
//        return cell
//    }
//
    @IBAction func slideBtnTapped(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SlideViewController") as! SlideViewController
        
        vc.delegate = self
        vc.pid = self.pid  // Pass the pid to SlideViewController
        
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: false, completion: nil)
    }

    func setAction(index: Int) {
        switch index {
        case 0:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
                    self.navigationController?.pushViewController(vc, animated: true)
        case 1:
            
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "medicationsVc") as! medicationsVc
            //let ids = viewPatient?.data[indexPath.row].id
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
            
        case 2:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "Viewreportsvc") as! Viewreportsvc
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "Graphsvc") as! Graphsvc
            vc.pid = self.pid ?? ""
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 4:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "viewSpouseInfovc") as! viewSpouseInfovc
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 5:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "medicalhistoryvc") as! medicalhistoryvc
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 6:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "viewadvicevc") as! viewadvicevc
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 7:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
           
                    let vc = storyBoard.instantiateViewController(withIdentifier: "ViewCycleupdatevc") as! ViewCycleupdatevc
            vc.pid = self.pid
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 8:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "doctorLoginvc") as! doctorLoginvc
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        case 9:
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                    let vc = storyBoard.instantiateViewController(withIdentifier: "EDITPatientInfovc") as! EDITPatientInfovc
            vc.pid = self.pid
            vc.patdetails = self.viewPatient
           
                    self.navigationController?.pushViewController(vc, animated: true)
            break
        
        default:
            print("hi")
        }
    }
    
//    @IBAction func bckbtn(_ sender: Any) {
//        // Get the reference to the storyboard
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        
//        // Instantiate the destination view controller
//        guard let vc = storyboard.instantiateViewController(withIdentifier: "patientListvc") as? patientListvc else {
//            // Handle the case where the view controller couldn't be instantiated
//            return
//        }
//        
//        // Push the destination view controller onto the navigation stack
//        navigationController?.pushViewController(vc, animated: true)
//    }
    @IBAction func bckbtn(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
       
               // Instantiate the destination view controller
               guard let vc = storyboard.instantiateViewController(withIdentifier: "patientListvc") as? patientListvc else {
                   // Handle the case where the view controller couldn't be instantiated
                   return
               }
       
               // Push the destination view controller onto the navigation stack
               navigationController?.pushViewController(vc, animated: true)
    }
    
    func fetchData() {
            guard let userId = pid else {
                print("User ID is nil")
                return
            }
        let formData = [
                    "userid": userId,
                ]
        APIHandler().postAPIValues(type: ViewPatientModel.self, apiUrl: ServiceAPI.ViewPatientURL , method: "POST", formData: formData) {
            [weak self] result in
                switch result {
                case .success(let viewPatient):
                   
                    DispatchQueue.main.async {
                        self?.viewPatient = viewPatient
                        print(viewPatient)
                        self?.nameLBL.text = viewPatient.patientDetails.name
                        self?.ageLBL.text = viewPatient.patientDetails.age
                        self?.patientidLBL.text = viewPatient.patientDetails.userid
                        self?.contactnumberLBL.text = viewPatient.patientDetails.contactNo
                        self?.genderLBL.text = viewPatient.patientDetails.gender
                        self?.weightLBL.text = viewPatient.patientDetails.weight
                        self?.medicalhistoryTEXTVIEW.text = viewPatient.patientDetails.medicalhistory
                        self?.addressLBL.text = viewPatient.patientDetails.address
                        self?.marrigeyearLBL.text = viewPatient.patientDetails.marriageyear
                        self?.heightLBL.text = viewPatient.patientDetails.height
                        self?.bloodgroupLBL.text = viewPatient.patientDetails.bloodgroup


                    }
                case .failure(let error):
                    print("Error fetching patient details: \(error)")
                }
            }
        }
    
}

extension ViewPatientvc : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ViewMedications?.patientDetails.count ?? 0
   }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"medicalcell", for: indexPath) as! medicalcell
        cell.medicinename.text =  ViewMedications?.patientDetails[indexPath.row].medicineName
        cell.medicinequantity.text =  ViewMedications?.patientDetails[indexPath.row].time
        cell.timing.text =  ViewMedications?.patientDetails[indexPath.row].quantity
        cell.date.text =  ViewMedications?.patientDetails[indexPath.row].date
        cell.when.text =  ViewMedications?.patientDetails[indexPath.row].when
              return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    
    
}
