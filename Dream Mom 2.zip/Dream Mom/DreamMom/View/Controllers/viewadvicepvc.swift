//
//  viewadvicepvc.swift
//  DreamMom
//
//  Created by SAIL on 22/11/23.
//

import UIKit

class viewadvicepvc:UIViewController {
    
    
    @IBOutlet weak var bckBtn: UIButton!
    
    @IBOutlet weak var advicestableview: UITableView!
    var pid1: String?
    var date: String?
    var ViewAdvices : ViewAdvicesModel?
    
    
//    var datearray = ["20/6/2023","23/5/2004"]
//    var advicearray = ["you are doing very good keepitup","keep going with the same medications"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        advicestableview.dataSource = self
        advicestableview.delegate = self
        advicestableview.reloadData()
       
        let cell = UINib(nibName: "AdviseCell", bundle: nil)
        advicestableview.register(cell, forCellReuseIdentifier: "cell")
        fetchData()
    }
    func fetchData() {
        
        guard let userId = pid1 else {
            print("User ID is nil")
            return
        }
        let formData = [
                    "userid": userId,
                ]
            
        APIHandler().postAPIValues(type: ViewAdvicesModel.self, apiUrl: ServiceAPI.ViewAdvicesURL , method: "POST", formData:formData) {
            [weak self] result in
            switch result {
            case .success(let data):
                
                if data.status == true {
                    DispatchQueue.main.async {
                    self?.ViewAdvices = data
                    self?.advicestableview.reloadData()
                    print(data)
                    }
                } else {
                   
                    DispatchQueue.main.async {
                    //self?.showAlert(title: "Error", message: "")
                    }
               
                }
            case .failure(let error):
                print(error)
                // Handle failure scenarios (e.g., network error)
//self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
            }
        }
        
    }
    
    
    
    
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return datearray.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier:"cell", for: indexPath) as! AdviseCell
//        cell.dateLbl.text = datearray[indexPath.row]
//        cell.paraOneLbl.text = advicearray[indexPath.row]
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 200.0
//    }
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
//                let vc = storyBoard.instantiateViewController(withIdentifier: "openadvicepvc") as! openadvicepvc
//                self.navigationController?.pushViewController(vc, animated: true)
//    }
    
    @IBAction func bckbtn(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "patienthomePagevc") as! patienthomePagevc
        vc.pid1 = self.pid1!
                self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
extension viewadvicepvc: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return ViewAdvices?.viewadvices.count ?? 0
    }
    
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"cell", for: indexPath) as! AdviseCell
        cell.dateLbl.text = ViewAdvices?.viewadvices[indexPath.row].addadvices
        cell.paraOneLbl.text = ViewAdvices?.viewadvices[indexPath.row].date
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "openadvicepvc") as! openadvicepvc
       
        if let date = ViewAdvices?.viewadvices[indexPath.row].date,
               let userid = ViewAdvices?.viewadvices[indexPath.row].userid {
                   vc.date1 = date
                   vc.pid1 = userid
    }
        
                self.navigationController?.pushViewController(vc, animated: true)
    }
    
    

}



