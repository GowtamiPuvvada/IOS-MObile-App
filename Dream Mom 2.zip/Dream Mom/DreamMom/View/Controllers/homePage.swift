//
//  homePage.swift
//  DreamMom
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class homePage: UIViewController {
    
    @IBOutlet weak var add: UIButton!
    @IBOutlet weak var viewpatient: UIButton!
    @IBOutlet weak var doctorprofile: UIButton!
    @IBOutlet weak var adddetailsView: UIView!
    @IBOutlet weak var modifydetailsView: UIView!
    var userID = Int()
    var pid: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func add(_ sender: Any) {
        let alert = UIAlertController(title: "Confirm", message: "Are you sure you want to add a doctor?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            self.addDoctor()
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func addDoctor() {
        // Make API request to add a doctor
        guard let url = URL(string: ServiceAPI.patientidURL) else {
            print("Invalid URL")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                // Handle error
                return
            }
            guard let data = data else {
                print("No data received")
                // Handle no data
                return
            }
            do {
                let decoder = JSONDecoder()
                let registrationResponse = try decoder.decode(patientidmodel.self, from: data)
                
                if registrationResponse.status {
                    // Store the dr_userid
                    self.userID = registrationResponse.userid
                    // Doctor added successfully
                    DispatchQueue.main.async {
                        var message = registrationResponse.message
                        message += "\nDoctor User ID: \(self.userID)"
                        
                        let successAlert = UIAlertController(title: "Success", message: message, preferredStyle: .alert)
                        successAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                            // Navigate to another view controller
                            self.navigateToNextViewController()
                        }))
                        self.present(successAlert, animated: true, completion: nil)
                    }
                } else {
                    // Error adding doctor
                    DispatchQueue.main.async {
                        let errorAlert = UIAlertController(title: "Error", message: registrationResponse.message, preferredStyle: .alert)
                        errorAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(errorAlert, animated: true, completion: nil)
                    }
                }
            } catch {
                print("Error parsing JSON: \(error)")
                // Handle JSON parsing error
            }
        }
        task.resume()
    }
    
    func navigateToNextViewController() {
        // Navigate to another view controller here
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddPatientInfovc") as! AddPatientInfovc
        // Pass the dr_userid to the next view controller
        vc.userID = self.userID
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func viewpatient(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientListvc") as! patientListvc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func doctorprofile(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "doctorProfilevc") as! doctorProfilevc
        vc.userID = userID
        //vc.pid = pid
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
