//
//  advicesvc.swift
//  DreamMom
//
//  Created by SAIL L1 on 17/11/23.
//

import UIKit

class advicesvc: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var textadvices: UITextView!
    @IBOutlet weak var addbutton: UIButton!
    @IBOutlet weak var dateLbl: UITextField!
    var pid: String?
    var AddAdvices: AddAdvicesModel?
    
    
    let placeholderText = "Enter your text here..."
    let placeholderTextColor = UIColor.lightGray
    
    
    
    let datePicker = UIDatePicker()
    let calendar = Calendar.current
    let currentDate = Date()
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        textadvices.text = placeholderText
        textadvices.textColor = placeholderTextColor
        textadvices.delegate = self
        
        textadvices.text = placeholderText
        
        
        
        datePicker.datePickerMode = .date
        let dateformatter = DateFormatter()
        dateformatter.timeZone = TimeZone.current
        dateformatter.dateFormat = "dd/MM/yy" // Change the date format here
        dateLbl.text = dateformatter.string(from: datePicker.date)
        dateLbl.isUserInteractionEnabled = false
        
//        self.dateLbl.setInputViewTimePicker(target: self, selector: #selector(tapDone))
        
        
        
        
    }
    
    @objc func tapDone() {
        if let picker = dateLbl.inputView as? UIDatePicker {
            let dateformatter = DateFormatter()
            dateformatter.timeZone = TimeZone.current
            dateformatter.dateFormat = "dd/MM/yy" // Change the date format here
            self.dateLbl.text = dateformatter.string(from: picker.date)
        }
        self.dateLbl.resignFirstResponder()
        
    }
    
    
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == placeholderTextColor {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = placeholderText
            textView.textColor = placeholderTextColor
        }
    }
    
    
    @IBAction func addbutton(_ sender: Any) {
        DispatchQueue.main.async { [self] in
            // print("UserId from UserDefault-->",userIds)
            print("UserID from data pass", self.pid)
            guard let userId = self.pid,
                  let advice = self.textadvices.text,
                  let Time: Date? = self.datePicker.date
            else {
                self.showAlert(title: "Error", message: "All fields are required")
                return
            }

            // Check if advice is empty
            if advice.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                self.showAlert(title: "Error", message: "Please add advice")
                return
            }

            let dateformatter = DateFormatter()
            dateformatter.dateFormat = "yyyy-MM-dd" // Change the date format here
            let formattedDate = dateformatter.string(from: Time ?? Date())

            let formData: [String: String] = [
                "userid": userId,
                "addadvice": advice,
                "date": formattedDate
            ]
            let trimmedAdvice = advice.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmedAdvice.isEmpty || trimmedAdvice == placeholderText {
                self.showAlert(title: "Error", message: "Please add advice")
                return
            }




            APIHandler().postAPIValues(type: AddAdvicesModel.self, apiUrl: ServiceAPI.AddAdvicesURL, method: "POST", formData: formData) {
                [weak self] result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        // Update UI based on API response here
                        if data.status == true {
                            let alert = UIAlertController(title: "Your ADVICE is added successfully!", message: " ", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { alert in
                                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                                let vc = storyBoard.instantiateViewController(withIdentifier: "viewadvicevc") as! viewadvicevc
                                vc.pid = self?.pid
                                self?.navigationController?.pushViewController(vc, animated: true)
                            }))
                            self?.present(alert, animated: true)
                        } else {
                            self?.showAlert(title: "Error", message: data.message)
                        }
                    }
                case .failure(let error):
                    print(error)
                    // Handle failure scenarios (e.g., network error)
                    self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                }
            }
        }
    }
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
        
    }
    
    //        let alertController = UIAlertController(title: "your ADVICE is added successfully!", message: " ", preferredStyle: .alert)
    //
    //        let cancelAction = UIAlertAction(title: "Done", style: .cancel) { _ in
    //
    //            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    //            let vc = storyBoard.instantiateViewController(withIdentifier: "viewadvicevc") as! viewadvicevc
    //          self.navigationController?.pushViewController(vc, animated: true)
    //        }
    //
    //
    //        alertController.addAction(cancelAction)
    //
    //
    //        if let viewController = UIApplication.shared.keyWindow?.rootViewController {
    //            viewController.present(alertController, animated: true, completion: nil)
    //        }
    
    
    @IBAction func bckbtn(_ sender: Any) {
//        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier: "Graphsvc") as! Graphsvc
//        vc.pid = self.pid ?? ""
//        self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
        
    }
}

    


