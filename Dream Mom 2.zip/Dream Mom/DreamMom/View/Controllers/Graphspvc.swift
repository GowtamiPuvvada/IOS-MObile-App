//
//  Graphspvc.swift
//  DreamMom
//
//  Created by SAIL on 22/11/23.
//

import UIKit

class Graphspvc: UIViewController {
    @IBOutlet weak var bckBTN: UIButton!
    @IBOutlet weak var barChartView: UIView!
    @IBOutlet weak var scrollViewWidthLayout: NSLayoutConstraint!
    var pid1: String = ""
    var graph: graphModel?
    var dataPoints: [String] = []
    var beforeValues: [CGFloat] = []
    var values: [CGFloat] = []
    var afterValues: [CGFloat] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchGraphData()
    }
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy" // Adjust the date format as per your requirement
        return formatter
    }()

    func fetchGraphData() {
        let apiURL = "\(ServiceAPI.graphURL)userid=\(pid1)" // Replace with your actual URL
        APIHandler().getAPIValues(type: graphModel.self, apiUrl: apiURL, method: "GET") { [self] result in
            switch result {
            case .success(let data):
                print(data)
                if data.status {
                    DispatchQueue.main.async { [self] in
                        print(data.data)
                        
                        dataPoints.append(contentsOf: data.data.map { $0.date })
                        print("dataPoints : \(dataPoints)")
                        scrollViewWidthLayout.constant = CGFloat(dataPoints.count * 160)
                        beforeValues = data.data.map { CGFloat($0.endometrium) }
                        afterValues = data.data.map { CGFloat($0.leftOvary) }
                        values = data.data.map { CGFloat($0.rightOvary) }

                        drawBarChart(dataPoints: dataPoints, beforeValues: beforeValues, values: values, afterValues: afterValues)
                    }
                } else {
                    showAlert(title: "Error", message: data.message, okActionHandler: {})
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    showAlert(title: "Failure", message: "Oops, something went wrong", okActionHandler: {})
                }
            }
        }
    }

    func drawBarChart(dataPoints: [String], beforeValues: [CGFloat], values: [CGFloat], afterValues: [CGFloat]) {
        let barWidth: CGFloat = 40
        let spaceBetweenBars: CGFloat = 10
        let maxBarHeight = barChartView.frame.height - 40  // Adjusting for label space
        let maxValue = max(beforeValues.max() ?? 0, values.max() ?? 0, afterValues.max() ?? 0)
        let maxYValue = maxValue * 1.1
        let unitHeight = maxBarHeight / maxYValue
        for index in 0..<dataPoints.count {
            
            let beforeValue = max(0, beforeValues[index])
                    let value = max(0, values[index])
                    let afterValue = max(0, afterValues[index])
            let beforeBarHeight = beforeValue * unitHeight
                    let barHeight = value * unitHeight
                    let afterBarHeight = afterValue * unitHeight
            
            let spaceBetweenGroups: CGFloat = 20
            let beforeBarX = CGFloat(index) * (3 * barWidth + 2 * spaceBetweenBars + spaceBetweenGroups)
            guard !beforeBarHeight.isNaN else {
                print("Invalid beforeBarHeight at index \(index)")
                continue
            }
            let beforeBarY = maxBarHeight - beforeBarHeight
            guard !beforeBarY.isNaN else {
                print("Invalid beforeBarY at index \(index)")
                continue
            }
            let barX = beforeBarX + barWidth + spaceBetweenBars
            let barY = maxBarHeight - barHeight

            let afterBarX = barX + barWidth + spaceBetweenBars
            let afterBarY = maxBarHeight - afterBarHeight

            let beforeBarLayer = CALayer()
            beforeBarLayer.frame = CGRect(x: beforeBarX, y: beforeBarY, width: barWidth, height: beforeBarHeight)
            beforeBarLayer.backgroundColor = UIColor.Green.cgColor
            barChartView.layer.addSublayer(beforeBarLayer)

            let barLayer = CALayer()
            barLayer.frame = CGRect(x: barX, y: barY, width: barWidth, height: barHeight)
            barLayer.backgroundColor = UIColor.Orange.cgColor
            barChartView.layer.addSublayer(barLayer)

            let afterBarLayer = CALayer()
            afterBarLayer.frame = CGRect(x: afterBarX, y: afterBarY, width: barWidth, height: afterBarHeight)
            afterBarLayer.backgroundColor = UIColor.Yellow.cgColor
            barChartView.layer.addSublayer(afterBarLayer)

            let label = UILabel(frame: CGRect(x: barX - 20 , y: maxBarHeight, width: 100, height: 20))
            label.text = dateFormatter.string(from: dateFormatter.date(from: dataPoints[index]) ?? Date())
            label.textAlignment = .center
            label.font = UIFont.systemFont(ofSize: 12)
            barChartView.addSubview(label)

            let beforeValueLabel = UILabel(frame: CGRect(x: beforeBarX, y: beforeBarY - 20, width: barWidth, height: 20))
            beforeValueLabel.text = "\(Float(beforeValue))"
            beforeValueLabel.textAlignment = .center
            beforeValueLabel.font = UIFont.systemFont(ofSize: 12)
            barChartView.addSubview(beforeValueLabel)

            let valueLabel = UILabel(frame: CGRect(x: barX, y: barY - 20, width: barWidth, height: 20))
            valueLabel.text = "\(Float(value))"
            valueLabel.textAlignment = .center
            valueLabel.font = UIFont.systemFont(ofSize: 12)
            barChartView.addSubview(valueLabel)

            let afterValueLabel = UILabel(frame: CGRect(x: afterBarX, y: afterBarY - 20, width: barWidth, height: 20))
            afterValueLabel.text = "\(Float(afterValue))"
            afterValueLabel.textAlignment = .center
            afterValueLabel.font = UIFont.systemFont(ofSize: 12)
            barChartView.addSubview(afterValueLabel)
            print("Before Bar Heights: \(beforeValues)")
            print("Bar Heights: \(values)")
            print("After Bar Heights: \(afterValues)")

        }
    }

    @IBAction func bckBTN(_ sender: Any) {
//        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier:"patienthomePagevc") as! patienthomePagevc
//        vc.pid1 = self.pid1
//
//        self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
    }
    

}
extension UIColor {
    // Neon Green
    static let Green = UIColor(red: 57/255, green: 255/255, blue: 20/255, alpha: 1.0)
    
    // Neon Blue
    static let Blue = UIColor(red: 10/255, green: 210/255, blue: 255/255, alpha: 1.0)
    
    // Neon Pink
    static let Pink = UIColor(red: 255/255, green: 20/255, blue: 147/255, alpha: 1.0)
    
    // Neon Yellow
    static let Yellow = UIColor(red: 204/255, green: 255/255, blue: 0/255, alpha: 1.0)
    
    // Neon Orange
    static let Orange = UIColor(red: 255/255, green: 165/255, blue: 0/255, alpha: 1.0)
    
    // Neon Purple
    static let Purple = UIColor(red: 190/255, green: 0/255, blue: 255/255, alpha: 1.0)
}
