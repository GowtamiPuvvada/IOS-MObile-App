//
//  Statusopenvc.swift
//  DreamMom
//
//  Created by vyas police on 18/12/23.
//

import UIKit

class Statusopenvc: UIViewController {

    @IBOutlet weak var bckBTN: UIButton!
    
    @IBOutlet weak var okbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func okbutton(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func bckBTN(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
