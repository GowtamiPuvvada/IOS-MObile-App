//
//  Addreportsnewvc.swift
//  DreamMom
//
//  Created by k. Dharani on 07/03/24.
//

import UIKit


    class Addreportsnewvc: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }

        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return days.count
        }

        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return days[row]
        }

        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            dayTEXTFEILD.text = days[row]
        }
        var temporaryTextFieldsValues: [String: String] = [:]
        @IBOutlet weak var imageIMAGEVIEW: UIImageView!
        @IBOutlet weak var bckBtn: UIButton!
        @IBOutlet weak var addreports: UIButton!
        @IBOutlet weak var dateTEXTFEILD: UITextField!
        @IBOutlet weak var dayTEXTFEILD: UITextField!
        @IBOutlet weak var save: UIButton!
        @IBOutlet weak var leftoveryTEXTFEILD: UITextField!
        @IBOutlet weak var rightoveryTEXTFEILD: UITextField!
        @IBOutlet weak var endometriumTEXTFEILD: UITextField!
        var pid: String?
        var selectedImage: UIImage?
        var AddReports: AddReportsModel?
        let placeholderText = "Enter your text here..."
        let placeholderTextColor = UIColor.lightGray
        let datePicker = UIDatePicker()
        let calendar = Calendar.current
        let currentDate = Date()
        let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        var textFieldsValues: [String: String] = [:]
        
        override func viewDidLoad() {
            super.viewDidLoad()
            if let image = selectedImage {
                imageIMAGEVIEW.image = image
            }
            datePicker.datePickerMode = .date
            datePicker.locale = Locale(identifier: "en_US")
            datePicker.minimumDate = currentDate
            // Assuming this function sets the input view to a date picker
            self.dateTEXTFEILD.setInputViewDatePicker(target: self, selector: #selector(tapDone))
            //loadTextFieldsValues()
            loadTemporaryTextFieldsValues()
            
        }
        override func viewWillDisappear(_ animated: Bool) {
            super.viewWillDisappear(animated)
            // Save text field values when navigating away from the view controller
            saveTextFieldsValues()
        }
        func loadTextFieldsValues() {
            // Load text field values from UserDefaults or any other temporary storage
            for (key, value) in temporaryTextFieldsValues {
                switch key {
                case "date":
                    dateTEXTFEILD.text = value
                case "day":
                    dayTEXTFEILD.text = value
                case "leftovery":
                    leftoveryTEXTFEILD.text = value
                case "rightovery":
                    rightoveryTEXTFEILD.text = value
                case "endometrium":
                    endometriumTEXTFEILD.text = value
                default:
                    break
                }
            }
        }
        func saveTextFieldsValues() {
            textFieldsValues["date"] = dateTEXTFEILD.text
            textFieldsValues["day"] = dayTEXTFEILD.text
            textFieldsValues["leftovery"] = leftoveryTEXTFEILD.text
            textFieldsValues["rightovery"] = rightoveryTEXTFEILD.text
            textFieldsValues["endometrium"] = endometriumTEXTFEILD.text
        }
        func loadTemporaryTextFieldsValues() {
            for (key, value) in temporaryTextFieldsValues {
                switch key {
                case "date":
                    dateTEXTFEILD.text = value
                case "day":
                    dayTEXTFEILD.text = value
                case "leftovery":
                    leftoveryTEXTFEILD.text = value
                case "rightovery":
                    rightoveryTEXTFEILD.text = value
                case "endometrium":
                    endometriumTEXTFEILD.text = value
                default:
                    break
                }
            }
        }
        func saveTemporaryTextFieldsValues() {
            // Save text field values temporarily
            temporaryTextFieldsValues["date"] = dateTEXTFEILD.text
            temporaryTextFieldsValues["day"] = dayTEXTFEILD.text
            temporaryTextFieldsValues["leftovery"] = leftoveryTEXTFEILD.text
            temporaryTextFieldsValues["rightovery"] = rightoveryTEXTFEILD.text
            temporaryTextFieldsValues["endometrium"] = endometriumTEXTFEILD.text
        }
        
        @IBAction func bckBtn(_ sender: Any) {
            let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "Viewreportsvc") as! Viewreportsvc
            vc.pid = self.pid
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        @objc func tapDone() {
            if let picker = dateTEXTFEILD.inputView as? UIDatePicker {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd" // Change the date format here to display only the date
                self.dateTEXTFEILD.text = dateFormatter.string(from: picker.date)
                
                // Calculate day from the selected date
                let dayOfWeek = Calendar.current.component(.weekday, from: picker.date)
                if dayOfWeek >= 1 && dayOfWeek <= days.count {
                    self.dayTEXTFEILD.text = days[dayOfWeek - 1]
                }
            }
            self.dateTEXTFEILD.resignFirstResponder()
        }
        
        @IBAction func save(_ sender: Any) {
            DispatchQueue.main.async {
                // print("UserId from UserDefault-->",userIds)
                print("UserID from data pass", self.pid)
                guard let userId = self.pid ,
                      let leftovery = self.leftoveryTEXTFEILD.text,
                      let rightovery = self.rightoveryTEXTFEILD.text,
                      let endometrium = self.endometriumTEXTFEILD.text,
                      let day = self.dayTEXTFEILD.text,
                      let date : Date? = self.datePicker.date
                        
                else {
                    self.showAlert(title: "Error", message: "All fields are required")
                    return
                }
                if leftovery.isEmpty || rightovery.isEmpty || endometrium.isEmpty || day.isEmpty || date == nil {
                    self.showAlert(title: "Error", message: "All fields are required")
                    return
                }
                
                let formData: [String: String] = [
                    "Userid": userId,
                    "Endometrium": endometrium,
                    "day": day,
                    "Leftovery": leftovery,
                    "Rightovery": rightovery,
                    "date": date.map { String(describing: $0) } ?? ""
                ]
                
                APIHandler().postAPIValues(type: AddReportsModel.self, apiUrl: ServiceAPI.AddReportsURL , method: "POST", formData: formData) {
                    [weak self] result in
                    switch result {
                    case .success(let data):
                        DispatchQueue.main.async {
                            // Update UI based on API response here
                            if data.status == true {
                                let alert = UIAlertController(title: "Success", message: "Reports saved successfully", preferredStyle: .alert)
                                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { alert in
                                    self?.navigationController?.popViewController(animated: true)
                                }))
                                self?.present(alert, animated: true)
                            } else {
                                self?.showAlert(title: "Error", message: data.message)
                            }
                        }
                    case .failure(let error):
                        print(error)
                        // Handle failure scenarios (e.g., network error)
                        self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                    }
                }
            }
        }
        
        func showAlert(title: String, message: String) {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        
        
        
    

}
