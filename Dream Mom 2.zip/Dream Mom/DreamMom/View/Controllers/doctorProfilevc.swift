import UIKit

class doctorProfilevc: UIViewController {

    @IBOutlet weak var editBtn: UIButton!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var driddisplayLBL: UILabel!
    @IBOutlet weak var drcontactnumLBL: UILabel!
    @IBOutlet weak var signoutBtn: UIButton!
    @IBOutlet weak var drnamedisplayLBL: UILabel!
    @IBOutlet weak var specificationdisplayLBL: UILabel!
    @IBOutlet weak var emaildisplayLBL: UILabel!
    var userID = Int()
    var pid: String?

    var doctorP: DoctorDetails? // Updated variable type to match the 'DoctorDetails' structure
    
    override func viewDidLoad() {
            super.viewDidLoad()
            fetchDoctorProfile()
        }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if let signupVC = segue.destination as? Signupvc {
                signupVC.doctorName = doctorP?.drName
                signupVC.doctorId = doctorP?.drUserid
                signupVC.doctorEmail = doctorP?.email
                signupVC.doctorNumber = doctorP?.contactNo ?? ""
                signupVC.doctorSpecification = doctorP?.designation
            }
        }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func signout(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                       let vc = storyBoard.instantiateViewController(withIdentifier: "doctorLoginvc") as! doctorLoginvc
                       self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func editbtn(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                     if let vc = storyBoard.instantiateViewController(withIdentifier: "Signupvc") as? Signupvc {
                         // Pass the data here
                         vc.doctorName = drnamedisplayLBL.text
                         vc.doctorId = driddisplayLBL.text
                         vc.doctorEmail = emaildisplayLBL.text
                         vc.doctorNumber = drcontactnumLBL.text
                         vc.doctorSpecification = specificationdisplayLBL.text

                         self.navigationController?.pushViewController(vc, animated: true)
                     }
           }

    func fetchDoctorProfile() {
        let formData = ["userid": userID]
        
        APIHandler().postAPIValues(type: doctorProfile.self, apiUrl: ServiceAPI.drProfiledisplayURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                // Check if doctorDetails is available
                if data.status {
                    let doctorDetails = data.doctorDetails
                    // Update UI with doctor details
                    DispatchQueue.main.async {
                        self?.driddisplayLBL.text = "\(doctorDetails.drUserid)"
                        self?.drnamedisplayLBL.text = doctorDetails.drName
                        self?.emaildisplayLBL.text = doctorDetails.email
                        self?.drcontactnumLBL.text = doctorDetails.contactNo
                        self?.specificationdisplayLBL.text = doctorDetails.designation
                    }
                } else {
                    print("No doctor details found.")
                }
            case .failure(let error):
                print("Error fetching doctor details: \(error)")
            }
        }
    }
    }
