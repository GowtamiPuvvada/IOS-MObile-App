import UIKit

class Viewdoctorvc: UIViewController {
    
    @IBOutlet weak var doctorlistTableview: UITableView!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var searchbar: UISearchBar!
    
    var doctorlist: doctorlistModel?
    var doctorSearch: doctorsearchModel?
    var searchOption = false
    var cellHeight: CGFloat = 50

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        doctorlistTableview.delegate = self
        doctorlistTableview.dataSource = self
        searchbar.delegate = self
        doctorlistTableview.rowHeight = UITableView.automaticDimension // Set table view row height to be calculated dynamically
        fetchData()
    }

    
    func fetchData() {
        searchOption = false
        APIHandler().postAPIValues(type: doctorlistModel.self, apiUrl: ServiceAPI.doctorlistURL, method: "POST", formData: [:]) { [weak self] result in
            switch result {
            case .success(let data):
                if data.status {
                    DispatchQueue.main.async {
                        self?.doctorlist = data
                        self?.doctorlistTableview.reloadData()
                        print("Fetch Doctor List Success:", data)
                    }
                } else {
                    DispatchQueue.main.async {
                        // Handle the case where data.status is false
                    }
                }
            case .failure(let error):
                print("Fetch Doctor List Error:", error)
                // Handle failure scenarios (e.g., network error)
                // self?.showAlert(title: "Error", message: "Failed to fetch data. Please try again.")
            }
        }
    }
    
    func searchApi(searchText: String) {
        if searchText.isEmpty {
            // If search text is empty, reload all data
            fetchData()
        } else {
            searchOption = true
            var formData: [String: String] = [:]
            
            // Check if searchText is a number (assuming user ID is numeric)
            if let userId = Int(searchText) {
                        formData["dr_userid"] = "\(userId)"
                    } else {
                        // Treat searchText as dr_name
                        formData["dr_name"] = searchText
                        // Treat searchText as designation
                        
                    }
            
            // Perform the search API request with formData
            APIHandler().postAPIValues(type: doctorsearchModel.self, apiUrl: ServiceAPI.doctorsearchURL, method: "POST", formData: formData) { [weak self] result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        if response.status {
                            // Check if search results array is present in the response
                            if let searchResults = response.search {
                                self?.doctorSearch = response
                                self?.doctorlistTableview.reloadData()
                            } else {
                                // Handle case where no search results are found
                                self?.doctorSearch = nil
                                self?.doctorlistTableview.reloadData()
                                self?.showAlert(title: "No Doctors Found", message: "No doctors found with the provided search criteria.")
                            }
                        } else {
                            // Handle API response indicating failure
                            print("Search Doctor API Error: API returned status false")
                        }
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        // Handle search API failure scenarios
                        print("Search Doctor API Error:", error)
                        self?.showAlert(title: "Error", message: "Failed to search for doctors. Please try again.")
                    }
                }
            }
        }
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }

    @IBAction func bckBtn(_ sender: Any) {let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddAdminvc") as! AddAdminvc
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
extension Viewdoctorvc: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder() // Hide the keyboard
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Debouncing or rate limiting is recommended here
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(self.reload(_:)), object: searchBar)
        self.perform(#selector(self.reload(_:)), with: searchBar, afterDelay: 0.5) // 0.5 seconds delay
    }
    
    @objc func reload(_ searchBar: UISearchBar) {
        guard let searchText = searchBar.text else { return }
        if searchText.isEmpty {
            fetchData() // Load all data if search text is cleared
        } else {
            searchApi(searchText: searchText) // Perform search with the current input
        }
    }
}


extension Viewdoctorvc: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchOption ? doctorSearch?.search?.count ?? 0 : doctorlist?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Alldoctorlist", for: indexPath) as? Alldoctorlist else {
            return UITableViewCell()
        }
        
        if let searchResults = doctorSearch?.search, indexPath.row < searchResults.count {
            cell.name.text = searchResults[indexPath.row].drName
            cell.drid.text = "\(searchResults[indexPath.row].drUserid ?? 0)"
           // cell.specification.text = searchResults[indexPath.row].designation
        }else {
            cell.name.text = doctorlist?.data[indexPath.row].drName
            cell.drid.text = "\(doctorlist?.data[indexPath.row].drUserid ?? 0)"
           // cell.specification.text = doctorlist?.data[indexPath.row].designation.rawValue
        }
        
        return cell
    }
}

extension Viewdoctorvc: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            // Add spacing between cells
            return UITableView.automaticDimension + 70 // Adjust the spacing as needed
        }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            // Set the desired space between two cells
            return 0// Increase the value for more spacing
        }
    

        func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            return UIView() // Return an empty UIView to create space between cells
        }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let specificDoctorVC = storyboard.instantiateViewController(withIdentifier: "viewSpecificdoctorvc") as? viewSpecificdoctorvc else {
            return // Unable to instantiate the view controller
        }
        
        if searchOption {
            // Pass the selected user ID for the searched doctor
            specificDoctorVC.dr_userid = doctorSearch?.search?[indexPath.row].drUserid ?? 0
        } else {
            // Pass the selected user ID for all doctors
            specificDoctorVC.dr_userid = doctorlist?.data[indexPath.row].drUserid ?? 0
        }
        
        navigationController?.pushViewController(specificDoctorVC, animated: true)
    }
}
