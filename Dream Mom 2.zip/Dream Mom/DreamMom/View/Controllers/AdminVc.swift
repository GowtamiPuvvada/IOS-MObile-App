//
//  AdminVc.swift
//  DreamMom
//
//  Created by k. Dharani on 09/03/24.
//

import UIKit

class AdminVc: UIViewController {

    @IBOutlet weak var loginbtn: UIButton!
    @IBOutlet weak var useridTextFeild: UITextField!
    @IBOutlet weak var passwordTextFeild: UITextField!
    
    var drLoginData : drloginModel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    
    @IBAction func loginbtn(_ sender: Any) {
            if useridTextFeild.text != "1920" {
                showAlert(title: "Alert", message: "Wrong admin ID")
            } else if passwordTextFeild.text?.isEmpty == true {
                showAlert(title: "Alert", message: "Enter password")
            } else {
                postAPI()
            }
        }
    func postAPI() {
            let apiURL = ServiceAPI.LogInURL
            let formData = [
                "userId": useridTextFeild.text ?? "",
                "password": passwordTextFeild.text ?? ""
            ]
            
            APIHandler().postAPIValues(type: drloginModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    switch result {
                    case .success(let data):
                        print(data)
                        if data.status {
                            self.navigateToHomePage()
                        } else {
                            self.showAlert(title: "Incorrect", message: "Incorrect User ID & Password")
                        }
                    case .failure(let error):
                        print(error)
                        self.showAlert(title: "Warning", message: "Something went wrong")
                    }
                }
            }
        }
            
            func navigateToHomePage() {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let homePageVC = storyboard.instantiateViewController(withIdentifier: "AddAdminvc") as! AddAdminvc
                navigationController?.pushViewController(homePageVC, animated: true)
            }
            
            func showAlert(title: String, message: String) {
                let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                present(alert, animated: true)
            }
    @IBAction func bckBTN(_ sender: Any) {
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "loginvc") as! loginvc
                self.navigationController?.pushViewController(vc, animated: true)
//        self.navigationController?.popViewController(animated: true)
        
    }
    
}
