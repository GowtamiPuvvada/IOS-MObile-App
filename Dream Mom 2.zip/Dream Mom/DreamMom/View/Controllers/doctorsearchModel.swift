//
//  doctorsearchModel.swift
//  DreamMom
//
//  Created by k. Dharani on 09/03/24.
//

import Foundation

// MARK: - Welcome
struct doctorsearchModel: Codable {
    let status: Bool
    let search: [doctorSearch]?
}

// MARK: - Search
struct doctorSearch: Codable {
    let drUserid: Int
    let drName, designation: String

    enum CodingKeys: String, CodingKey {
        case drUserid = "dr_userid"
        case drName = "dr_name"
        case designation
    }
}
enum Designation1: String, Codable {
    case designation = "designation"
    case empty = ""
    case ortho = "ortho"
}
