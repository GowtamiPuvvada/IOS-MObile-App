//
//  PatientInfovc.swift
//  DreamMom
//
//  Created by SAIL on 31/01/24.
//

import UIKit

class PatientInfovc: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource{
    
    
    
    
    @IBOutlet weak var bckBTN: UIButton!
    @IBOutlet weak var medicalhistoryTEXTVIEW: UITextView!
    @IBOutlet weak var addressTEXTVIEW: UITextView!
    @IBOutlet weak var weightTEXTFEILD: UITextField!
    @IBOutlet weak var heightTEXTFEILD: UITextField!
    @IBOutlet weak var genderTEXTFEILD: UITextField!
    @IBOutlet weak var saveBTN: UIButton!
    @IBOutlet weak var ageTEXTFEILD: UITextField!
    @IBOutlet weak var bloodgroupTEXTFEILD: UITextField!
    @IBOutlet weak var yomTEXTFEILD: UITextField!
    @IBOutlet weak var mobilenumberTEXTFEILD: UITextField!
    @IBOutlet weak var nameTEXTFEILD: UITextField!
    @IBOutlet weak var idTEXTFEILD: UITextField!
    var formData: [String: String]?
    
    var id: String?
    var patdetails:ViewPatientModel?
    var editpatientprofile:editpatientprofileModel?
    let bloodGroupPickerView = UIPickerView()
        let genderPickerView = UIPickerView()
    let dobDatePicker = UIDatePicker()

        // Add data sources for picker views
        let bloodGroupData = ["A+", "A-",
                              "B+", "B-",
                              "AB+", "AB-",
                              "O+", "O-"]
        let genderData = ["Male", "Female", "Other"]

        // Add date picker for year of marriage
        let marriageYearDatePicker = UIDatePicker()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let address = self.patdetails?.patientDetails.address {
            addressTEXTVIEW.text = address
        }
        if let weight = self.patdetails?.patientDetails.weight {
            weightTEXTFEILD.text = weight
        }
        if let height = self.patdetails?.patientDetails.height {
            heightTEXTFEILD.text = height
        }
        if let gender = self.patdetails?.patientDetails.gender {
            genderTEXTFEILD.text = gender
            
        }
        if let age = self.patdetails?.patientDetails.age {
            ageTEXTFEILD.text = age
            
        }
        if let id = self.patdetails?.patientDetails.userid {
            idTEXTFEILD.text = id
            
        }
        if let phone_no = self.patdetails?.patientDetails.contactNo {
            mobilenumberTEXTFEILD.text = phone_no
            
        }
        if let bloodgroup = self.patdetails?.patientDetails.bloodgroup {
            bloodgroupTEXTFEILD.text = bloodgroup
            
        }
        if let name = self.patdetails?.patientDetails.name {
            nameTEXTFEILD.text = name
            
        }
        if let marriage = self.patdetails?.patientDetails.marriageyear {
            yomTEXTFEILD.text = marriage
            
        }
        if let medhist = self.patdetails?.patientDetails.medicalhistory {
            if let medhist = self.patdetails?.patientDetails.medicalhistory {
                medicalhistoryTEXTVIEW.text = medhist
                
            }
            bloodGroupPickerView.delegate = self
                    bloodGroupPickerView.dataSource = self
                    genderPickerView.delegate = self
                    genderPickerView.dataSource = self

                    // Set input view for text fields
                    bloodgroupTEXTFEILD.inputView = bloodGroupPickerView
                    genderTEXTFEILD.inputView = genderPickerView
            marriageYearDatePicker.datePickerMode = .date
                    marriageYearDatePicker.addTarget(self, action: #selector(handleMarriageYearDatePickerChange), for: .valueChanged)

                    // Set input view for the year of marriage text field
                    yomTEXTFEILD.inputView = marriageYearDatePicker
            dobDatePicker.datePickerMode = .date
                   dobDatePicker.maximumDate = Date() // Set the maximum date to today
                   dobDatePicker.addTarget(self, action: #selector(handleDOBDatePickerChange), for: .valueChanged)

                   // Set input view for the date of birth text field
                   ageTEXTFEILD.inputView = dobDatePicker
            addDoneButton(to: bloodgroupTEXTFEILD)
                   addDoneButton(to: genderTEXTFEILD)
                   addDoneButton(to: ageTEXTFEILD)
                   addDoneButton(to: yomTEXTFEILD)
        }
        

    }
    @objc func doneButtonPressed() {
           view.endEditing(true)
       }
    private func addDoneButton(to textField: UITextField) {
            let toolbar = UIToolbar()
            toolbar.sizeToFit()

            let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonPressed))
            let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)

            toolbar.setItems([flexibleSpace, doneButton], animated: true)

            textField.inputAccessoryView = toolbar
        }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }

        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            if pickerView == bloodGroupPickerView {
                return bloodGroupData.count
            } else if pickerView == genderPickerView {
                return genderData.count
            }
            return 0
        }

        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            if pickerView == bloodGroupPickerView {
                return bloodGroupData[row]
            } else if pickerView == genderPickerView {
                return genderData[row]
            }
            return nil
        }

        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            if pickerView == bloodGroupPickerView {
                bloodgroupTEXTFEILD.text = bloodGroupData[row]
            } else if pickerView == genderPickerView {
                genderTEXTFEILD.text = genderData[row]
            }
        }

        // Date Picker handler
    @objc func handleMarriageYearDatePickerChange() {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy"
            yomTEXTFEILD.text = dateFormatter.string(from: marriageYearDatePicker.date)
        }
    @objc func handleDOBDatePickerChange() {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let selectedDate = dobDatePicker.date
            ageTEXTFEILD.text = calculateAge(from: selectedDate)
        }

        func calculateAge(from date: Date) -> String {
            let calendar = Calendar.current
            let currentDate = Date()
            let ageComponents = calendar.dateComponents([.year], from: date, to: currentDate)

            if let age = ageComponents.year {
                return "\(age) years"
            } else {
                return ""
            }
        }
    @IBAction func bckBUTTN(_ sender: Any) {
        // let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        self.navigationController?.popViewController(animated: true)
        //        let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
        //        vc.pid = self.pid
        //
        //        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func savebTN(_ sender: Any) {
        
        
        
        updateViewProfille()
        DispatchQueue.main.async
        
        {
            // print("UserId from UserDefault-->",userIds)
            print("UserID from data pass", self.id)
            guard let userId = self.id ,
                  let name = self.nameTEXTFEILD.text ,
                  let contactnumber = self.mobilenumberTEXTFEILD.text,
                  let age = self.ageTEXTFEILD.text,
                  let gender = self.genderTEXTFEILD.text,
                  let height = self.heightTEXTFEILD.text,
                  let weight = self.weightTEXTFEILD.text,
                  let address = self.addressTEXTVIEW.text,
                  let marriageyear = self.yomTEXTFEILD.text,
                  let bloodgroup = self.bloodgroupTEXTFEILD.text,
                  let medicalhistory =  self.medicalhistoryTEXTVIEW.text
                    
                    
            else {
                self.showAlert(title: "Error", message: "All fields are required")
                return
            }
            
            
            let formData: [String: String] = [
                "userid": userId,
                "name": name,
                "contactno": contactnumber,
                "age": age,
                "gender": gender,
                "height": height,
                "weight": weight,
                "address": address,
                "marriageyear": marriageyear,
                "bloodgroup": bloodgroup,
                "medicalhistory": medicalhistory,
                "specifications" : ""
                
            ]
            APIHandler().postAPIValues(type: editpatientprofileModel.self, apiUrl: ServiceAPI.editpatientprofileURL , method: "POST", formData: formData) {
                [weak self] result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        // Update UI based on API response here
                        if data.status == true  {
                            let alert = UIAlertController(title: "Success", message: "Reports saved successfully", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
                                let vc = storyBoard.instantiateViewController(withIdentifier: "ViewPatientvc") as! ViewPatientvc
                                vc.pid = self!.id
                                self?.navigationController?.pushViewController(vc, animated: true)
                            }))
                            
                            
                            
                        } else {
                            self?.showAlert(title: "Error", message:" ")
                        }
                    }
                case .failure(let error):
                    print(error)
                    // Handle failure scenarios (e.g., network error)
                    self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                }
            }
            
        }
        
    }
    private func handleNonJSONResponse(data: Data?) {
        if let responseData = data, let responseString = String(data: responseData, encoding: .utf8) {
            print("Non-JSON Response: \(responseString)")
            
            // Handle the non-JSON response based on your requirements
            // For example, display an alert with the response string
            showAlert(title: "Non-JSON Response", message: responseString)
        } else {
            showAlert(title: "Error", message: "Failed to update patient information. Please try again.")
        }
    }
    
    
    func updateViewProfille() {
        if let vc = navigationController?.viewControllers.first as? ViewPatientvc {
            vc.viewPatient = patdetails
            if let userID = patdetails?.patientDetails.userid{
                vc.patientidLBL.text = userID
            }
            if let name = patdetails?.patientDetails.name{
                vc.nameLBL.text = name
            }
            if let contactnumber = patdetails?.patientDetails.contactNo{
                vc.contactnumberLBL.text = contactnumber
            }
            if let age = patdetails?.patientDetails.age{
                vc.ageLBL.text = age
            }
            if let gender = patdetails?.patientDetails.gender{
                vc.genderLBL.text = gender
            }
            if let height = patdetails?.patientDetails.height{
                vc.heightLBL.text = height
            }
            if let weight = patdetails?.patientDetails.weight{
                vc.weightLBL.text = weight
            }
            if let address = patdetails?.patientDetails.address{
                vc.addressLBL.text = address
            }
            if let marriageyear = patdetails?.patientDetails.marriageyear{
                vc.marrigeyearLBL.text = marriageyear
            }
            if let bloodgroup = patdetails?.patientDetails.bloodgroup{
                vc.bloodgroupLBL.text = bloodgroup
            }
            if let medicalhistory = patdetails?.patientDetails.bloodgroup{
                vc.medicalhistoryTEXTVIEW.text = medicalhistory
            }
            
        }
        
        navigationController?.popViewController(animated: true)
    }
    
    func showAlert(title: String, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        
        
    }
}

