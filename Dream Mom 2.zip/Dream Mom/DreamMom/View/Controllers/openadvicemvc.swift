//
//  openadvicemvc.swift
//  DreamMom
//
//  Created by SAIL on 24/11/23.
//

import UIKit

class openadvicemvc: UIViewController {

    @IBOutlet weak var dateLBL: UILabel!
    @IBOutlet weak var bckBtn: UIButton!
    
    @IBOutlet weak var DisplayAdvicesTABLEVIEW: UITableView!
    
    var pid: String?
    var date1: String?
    var sviewadvice: sviewadviceModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        DisplayAdvicesTABLEVIEW.dataSource = self
        DisplayAdvicesTABLEVIEW.delegate = self
        let cell = UINib(nibName: "sopenadvicescell", bundle: nil)
        DisplayAdvicesTABLEVIEW.register(cell, forCellReuseIdentifier: "sopenadvicescell")
        DisplayAdvicesTABLEVIEW.reloadData()
        fetchData()

       
    }
    func fetchData() {
            guard let userId = pid,
                  let selectedDate = date1 else {
                print("User ID or date is nil")
                return
            }
        let formData = [
                    "userid": userId,
                    "date":selectedDate
                ]
        APIHandler().postAPIValues(type: sviewadviceModel.self, apiUrl: ServiceAPI.sviewadviceURL , method: "POST", formData: formData) {
            [weak self] result in
                switch result {
                case .success(let sviewadvice1):
                    if sviewadvice1.status == true {
                        DispatchQueue.main.async {
                        self?.sviewadvice = sviewadvice1
                            self?.dateLBL.text = sviewadvice1.sviewadvices.first?.date
                        self?.DisplayAdvicesTABLEVIEW.reloadData()
                        print(sviewadvice1)
                        }
                    } else {
                       
                        DispatchQueue.main.async {
                        //self?.showAlert(title: "Error", message: "")
                        }
                   
                    }
                case .failure(let error):
                    print(error)
                   
                
                    
                }
            }
        }
    
    

    @IBAction func bckbtn(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "viewadvicevc") as! viewadvicevc
        vc.pid = self.pid
      self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension openadvicemvc: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return sviewadvice?.sviewadvices.count ?? 0
    }
    
   
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"sopenadvicescell", for: indexPath) as! sopenadvicescell
        cell.openAdvicesTEXTVIEW.text = sviewadvice?.sviewadvices[indexPath.row].addadvices
       
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 600.0
    }
    
    
    

}
