//
//  Signupvc.swift
//  DreamMom
//
//  Created by SAIL on 21/11/23.
//

import UIKit

class Signupvc: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var IdTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var numberTF: UITextField!
    @IBOutlet weak var passworfTF: UITextField!
    var pid: String?
    var userID = Int()
    
   
    @IBOutlet weak var specificationTF: UITextField!
    var doctorName: String?
    var doctorId: String?
    var doctorEmail: String?
    var doctorNumber: String?
    var doctorSpecification: String?
    override func viewDidLoad() {
            super.viewDidLoad()

            // Set the text fields with the passed data
            if let name = doctorName {
                nameTF.text = name
            }
//            if let id = doctorId {
//                IdTF.text = id
//            }
            if let email = doctorEmail {
                emailTF.text = email
            }
            if let number = doctorNumber {
                numberTF.text = number
            }
            if let specification = doctorSpecification {
                specificationTF.text = specification
            }

            numberTF.delegate = self
            emailTF.delegate = self
        }

    private func setupInitialValues() {
        nameTF.text = doctorName
        if let doctorId = doctorId {
            IdTF.text = doctorId
        }
        if let doctorEmail = doctorEmail {
            emailTF.text = doctorEmail
        }
        if let doctorNumber = doctorNumber {
            numberTF.text = doctorNumber
        }
        if let doctorSpecification = doctorSpecification {
            specificationTF.text = doctorSpecification
        }
    }




    @IBAction func submit(_ sender: Any) {

                signupAPI()
        }


    @IBAction func bckBtn(_ sender: Any) {
//        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier: "doctorProfilevc") as! doctorProfilevc
//        self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
    }

    func signupAPI() {
        if let email = emailTF.text, !email.isEmpty, !email.contains("@gmail.com") {
                showAlertWithMessage("Email must end with @gmail.com")
                return
            }
            
            // Validate number if it's not empty
            if let number = numberTF.text, !number.isEmpty, number.count != 10 {
                showAlertWithMessage("Number must be 10 digits")
                return
            }
        
        var formData: [String: String] = [
            "userId": "doctorId",
        ]

        if let name = nameTF.text, !name.isEmpty {
            formData["name"] = name
        }

        if let designation = specificationTF.text, !designation.isEmpty {
            formData["designation"] = designation
        }

        if let email = emailTF.text, !email.isEmpty {
            formData["email"] = email
        }

        if let number = numberTF.text, !number.isEmpty {
            formData["contactno"] = number
        }

        print(formData, ServiceAPI.editprofile)

        APIHandler().postAPIValues(type: EditUserData.self, apiUrl: ServiceAPI.editprofile, method: "POST", formData: formData) { [self] result in
            DispatchQueue.main.async {
                        switch result {
                        case .success(let data):
                            print(data.message)
                           
                            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                  let vc = storyBoard.instantiateViewController(withIdentifier: "homePage") as! homePage
                         //   vc.userID = doctorId
                            // Assuming doctorId is a String?
                            if let doctorIdString = doctorId, let doctorIdInt = Int(doctorIdString) {
                                vc.userID = doctorIdInt
                            } else {
                                // Handle the case where doctorId is nil or cannot be converted to Int
                                print("Error: Unable to convert doctorId to Int")
                            }



                                  self.navigationController?.pushViewController(vc, animated: true)

                        case .failure(let error):
                            print("Network Error: \(error)")
                          
                            let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                          
                            })
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
            }




    func showAlertWithMessage(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
