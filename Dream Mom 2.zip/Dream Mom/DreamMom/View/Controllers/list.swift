//
//  list.swift
//  DreamMom
//
//  Created by SAIL L1 on 17/11/23.
//Lbl : label
// Btn : Button
//Txt : Textfield


import UIKit

class list: UITableViewCell {
    
    @IBOutlet weak var patientname: UILabel!
    @IBOutlet weak var patientnum: UILabel!
    @IBOutlet weak var delete: UIButton!
    
//    var patientName = ""
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
}
