import UIKit

class AddSpouseController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate {

    @IBOutlet weak var saveBTN: UIButton!
    @IBOutlet weak var nameTEXTFEILD: UITextField!
    @IBOutlet weak var contactnumberTEXTFEILD: UITextField!
    @IBOutlet weak var bloodgroupTEXTFEILD: UITextField!
    @IBOutlet weak var weightTEXTFEILD: UITextField!
    @IBOutlet weak var heightTEXTFEILD: UITextField!
    @IBOutlet weak var ageTEXTFEILD: UITextField!
    @IBOutlet weak var bckBtn: UIButton!
    @IBOutlet weak var medicalhistoryTEXTVIEW: UITextView!
    var id: String?
    let bloodGroupPicker = UIPickerView()
    let bloodGroupData = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"]
    let ageDatePicker = UIDatePicker()
    let ageData = Array(18...67)
    let agePicker = UIPickerView()

//    override func viewDidLoad() {
//        super.viewDidLoad()
//        print(id ?? "")
//        // Do any additional setup after loading the view.
////        bloodGroupPicker.delegate = self
////        bloodGroupPicker.dataSource = self
////        bloodgroupTEXTFEILD.inputView = bloodGroupPicker
//        setupBloodGroupPicker()
//
//        // Add a toolbar with a Done button
//        let toolbar = UIToolbar()
//        toolbar.sizeToFit()
//        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissKeyboard))
//        toolbar.setItems([doneButton], animated: false)
//        toolbar.isUserInteractionEnabled = true
//        bloodgroupTEXTFEILD.inputAccessoryView = toolbar
//
//        setupDatePicker(picker: ageDatePicker, textField: ageTEXTFEILD)
//        bloodgroupTEXTFEILD.delegate = self
//               ageTEXTFEILD.delegate = self
//        setupTextViewPlaceholder()
//            }
    override func viewDidLoad() {
            super.viewDidLoad()
            print(id ?? "")
            setupBloodGroupPicker()
            setupAgePicker()
            setupTextViewPlaceholder()
        }
    private func setupAgePicker()
    {
           agePicker.delegate = self
           agePicker.dataSource = self
           ageTEXTFEILD.inputView = agePicker
           
           setupPickerToolbar(for: ageTEXTFEILD)
       }
    private func setupPickerToolbar(for textField: UITextField) {
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissKeyboard))
            toolbar.setItems([doneButton], animated: false)
            toolbar.isUserInteractionEnabled = true
            textField.inputAccessoryView = toolbar
        }

    private func setupBloodGroupPicker() {
            bloodGroupPicker.delegate = self
            bloodGroupPicker.dataSource = self
        bloodgroupTEXTFEILD.inputView = bloodGroupPicker
            
            let toolbar = UIToolbar()
            toolbar.sizeToFit()
            let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissKeyboard))
            toolbar.setItems([doneButton], animated: false)
            toolbar.isUserInteractionEnabled = true
        bloodgroupTEXTFEILD.inputAccessoryView = toolbar
        }
    private func setupTextViewPlaceholder() {
            medicalhistoryTEXTVIEW.delegate = self
            medicalhistoryTEXTVIEW.text = "Enter Medical History"
            medicalhistoryTEXTVIEW.textColor = UIColor.lightGray
        }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == bloodgroupTEXTFEILD && bloodgroupTEXTFEILD.text!.isEmpty {
            // Set to default value based on the initial selection in the picker
            let defaultIndex = bloodGroupPicker.selectedRow(inComponent: 0)
            bloodgroupTEXTFEILD.text = bloodGroupData[defaultIndex]
        } else if textField == ageTEXTFEILD && ageTEXTFEILD.text!.isEmpty {
            // Set to default value based on the initial selection in the picker
            let defaultIndex = agePicker.selectedRow(inComponent: 0)
            ageTEXTFEILD.text = "\(ageData[defaultIndex])"
        }

        // Add logic to show the picker for the specified text field
        if textField == bloodgroupTEXTFEILD {
            bloodgroupTEXTFEILD.inputView = bloodGroupPicker
        } else if textField == ageTEXTFEILD {
            ageTEXTFEILD.inputView = agePicker
        }
    }


//    func textFieldDidBeginEditing(_ textField: UITextField) {
//            if textField == bloodgroupTEXTFEILD || textField == ageTEXTFEILD {
//                // Display the picker for blood group and age text fields
//                showPicker(for: textField)
//            }
//        }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            if textField == bloodgroupTEXTFEILD || textField == ageTEXTFEILD {
                // Prevent manual entry and display alert
                showAlert(title: "Error ", message: "Please use the picker for this field.")
                return false
            }
            return true
        }

    private func showPicker(for textField: UITextField) {
        
        if textField == bloodgroupTEXTFEILD && bloodgroupTEXTFEILD.text!.isEmpty {
            
            let defaultIndex = bloodGroupPicker.selectedRow(inComponent: 0)
            bloodgroupTEXTFEILD.text = bloodGroupData[defaultIndex]
            
        } else if textField == ageTEXTFEILD && ageTEXTFEILD.text!.isEmpty {
            
            let defaultIndex = agePicker.selectedRow(inComponent: 0)
            ageTEXTFEILD.text = "\(ageData[defaultIndex])"
        }

        if textField == bloodgroupTEXTFEILD {
            bloodgroupTEXTFEILD.becomeFirstResponder()
           
        } else if textField == ageTEXTFEILD {
            ageTEXTFEILD.becomeFirstResponder()
          
        }
    }

    private func setupDatePicker(picker: UIDatePicker, textField: UITextField) {
        picker.datePickerMode = .date
        picker.maximumDate = Date() // Set the maximum date to today
        picker.addTarget(self, action: #selector(dateOfBirthDidChange(_:)), for: .valueChanged)

        // Add a toolbar with a Done button
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(dismissKeyboard))
        toolbar.setItems([doneButton], animated: false)
        toolbar.isUserInteractionEnabled = true
        textField.inputView = picker
        textField.inputAccessoryView = toolbar
    }

    @objc func dateOfBirthDidChange(_ sender: UIDatePicker) {
        let selectedDate = sender.date
        let age = calculateAge(from: selectedDate)
        print(age)
        ageTEXTFEILD.text = "\(age) years"
    }

    private func calculateAge(from date: Date) -> Int {
        let currentDate = Date()
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year], from: date, to: currentDate)
        return components.year ?? 0
    }
   


    @objc func dismissKeyboard() {
        view.endEditing(true)
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
           if pickerView == agePicker {
               return ageData.count
           }
           return bloodGroupData.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            if pickerView == agePicker {
                ageTEXTFEILD.text = "\(ageData[row])"
                return "\(ageData[row])"
            }
        bloodgroupTEXTFEILD.text = bloodGroupData[row]
            return bloodGroupData[row]
        }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == bloodGroupPicker {
            bloodgroupTEXTFEILD.text = bloodGroupData[row]
        } else if pickerView == agePicker {

            ageTEXTFEILD.text = "\(ageData[row])"
        }
    }

    @IBAction func bckBtn(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddPatientInfovc") as! AddPatientInfovc
        vc.id = self.id
        self.navigationController?.pushViewController(vc, animated: true)
    }

    @IBAction func saveBtnTapped(_ sender: Any) {
        DispatchQueue.main.async { [self] in
            let userIds = UserDefaults.standard.string(forKey: "userId")

            guard let userId = userIds else {
                self.showAlert(title: "Error", message: "User ID is missing")
                return
            }

            guard let name = self.nameTEXTFEILD.text, !name.isEmpty else {
                self.showAlert(title: "Error", message: "Name is required")
                return
            }

            guard let contactNo = self.contactnumberTEXTFEILD.text, contactNo.count == 10, CharacterSet.decimalDigits.isSuperset(of: CharacterSet(charactersIn: contactNo)) else {
                self.showAlert(title: "Error", message: "Invalid or missing contact number")
                return
            }

            guard let age = self.ageTEXTFEILD.text, !age.isEmpty else {
                self.showAlert(title: "Error", message: "Age is required")
                return
            }

            guard let height = self.heightTEXTFEILD.text, !height.isEmpty else {
                self.showAlert(title: "Error", message: "Height is required")
                return
            }

            guard let weight = self.weightTEXTFEILD.text, !weight.isEmpty else {
                self.showAlert(title: "Error", message: "Weight is required")
                return
            }

//            guard let medicalhistory = self.medicalhistoryTEXTVIEW.text else {
//                self.showAlert(title: "Error", message: "Medical history is required")
//                return
//            }
            guard let medicalhistory = medicalhistoryTEXTVIEW.text,
                  medicalhistory != "Enter Medical History" && !medicalhistory.isEmpty else {
                showAlert(title: "Error", message: "ALL FIELDS ARE REQUIRED")
                return
            }

            guard let bloodGroup = self.bloodgroupTEXTFEILD.text, !bloodGroup.isEmpty else {
                self.showAlert(title: "Error", message: "Blood group is required")
                return
            }

            let formData = [
                "userid": userId,
                "name": name,
                "contactno": contactNo,
                "age": age,
                "height": height,
                "weight": weight,
                "bloodgroup": bloodGroup,
                "medicalhistory": medicalhistory
            ]

            APIHandler().postAPIValues(type: AddspouseModel.self, apiUrl: ServiceAPI.addspouseURL , method: "POST", formData: formData) {
                [weak self] result in
                switch result {
                case .success(let data):
                    print(data)
                    if data.status == true {
                        // Handle success
                    } else {
                        DispatchQueue.main.async {
                            self?.showAlert(title: "Error", message: data.message)
                        }
                    }
                case .failure(let error):
                    print(error)
                    // Handle failure scenarios (e.g., network error)
                    self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
                }
            }

            guard !(self.presentedViewController is UIAlertController) else {
                // UIAlertController is already presented, do not present again
                return
            }

            let alertController = UIAlertController(title: "Do you have undergone this treatment before?", message: " ", preferredStyle: .alert)

            let cancelAction = UIAlertAction(title: "Yes", style: .cancel) { [weak self] _ in
                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "Specificationsvc") as! Specificationsvc
                self?.navigationController?.pushViewController(vc, animated: true)
            }

            let okAction = UIAlertAction(title: "No", style: .default) { _ in
                let storyBoard = UIStoryboard(name: "Main", bundle: nil)
                let vc = storyBoard.instantiateViewController(withIdentifier: "patientListvc") as! patientListvc
                self.navigationController?.pushViewController(vc, animated: true)
            }

            alertController.addAction(cancelAction)
            alertController.addAction(okAction)

            if let viewController = UIApplication.shared.keyWindow?.rootViewController {
                viewController.present(alertController, animated: true, completion: nil)
            }
        }
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true)
    }
}
extension AddSpouseController: UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.text == "Enter Medical History" {
            textView.text = ""
            textView.textColor = UIColor.black
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Enter Medical History"
            textView.textColor = UIColor.lightGray
        }
    }
}
