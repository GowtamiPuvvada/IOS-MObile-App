//
//  ResetPasswordVC.swift
//  DreamMom
//
//  Created by vyas police on 19/12/23.
//
//have to do reset password similar to edit pass
import UIKit

class ResetPasswordVC: UIViewController {
    
    @IBOutlet weak var bckBTN: UIButton!
    @IBOutlet weak var id: UILabel!
    
    @IBOutlet weak var repasswordTXTFEILD: UITextField!
    @IBOutlet weak var passTXTFEILD: UITextField!
    @IBOutlet weak var submitBTN: UIButton!
    var pid1 : String?
    var password : passwordModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("PID passed is --",pid1 ?? "")
        id.text = pid1 ?? ""
        // Do any additional setup after loading the view.
    }
    
    @IBAction func bckBTN(_ sender: Any) {
        //        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        //                let vc = storyBoard.instantiateViewController(withIdentifier: "patientLoginvc") as! patientLoginvc
        //        vc.pid1 = self.pid1 ?? ""
        //                self.navigationController?.pushViewController(vc, animated: true)
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitBTN(_ sender: Any) {
        postAPI()
        
        //        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        //                let vc = storyBoard.instantiateViewController(withIdentifier: "patientLoginvc") as! patientLoginvc
        //                self.navigationController?.pushViewController(vc, animated: true)
        
    }
    func postAPI() {
        guard let unwrappedPid1 = pid1,
              let password = passTXTFEILD.text,
              let repassword = repasswordTXTFEILD.text else { return }
        
        let formData = [
            "userid": unwrappedPid1,
            "password": password,
            "repassword": repassword,
        ]
        
        APIHandler().postAPIValues(type: passwordModel.self, apiUrl: ServiceAPI.passwordURL, method: "POST", formData: formData) {
            [weak self] result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    // Update UI based on API response here
                    if data.status == true {
                        let alert = UIAlertController(title: "Success", message: "Password updated successfully", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { alert in
                            self?.navigationController?.popViewController(animated: true)
                        }))
                        self?.present(alert, animated: true)
                    } else {
                        self?.showAlert(title: "Error", message: data.message)
                    }
                }
            case .failure(let error):
                print(error)
                // Handle failure scenarios (e.g., network error)
                self?.showAlert(title: "Error", message: "Failed to register patient. Please try again.")
            }
        }
    }
    
    func showAlert(title: String, message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
}
