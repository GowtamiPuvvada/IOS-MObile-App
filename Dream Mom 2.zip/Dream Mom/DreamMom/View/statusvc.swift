//
//  statusvc.swift
//  DreamMom
//
//  Created by k. Dharani on 24/11/23.
//

import UIKit

class statusvc: UITableViewCell {

    @IBOutlet weak var day: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var Lo: UILabel!
    @IBOutlet weak var Ro: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
   
  
    
}
