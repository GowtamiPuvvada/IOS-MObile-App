import Foundation

struct DoctorRegistrationResponse: Codable {
    let status: Bool
    let message: String
    let dr_userid: Int
}

