//
//  SearchbarModel.swift
//  DreamMom
//
//  Created by vyas police on 04/01/24.
//
import Foundation

// MARK: - Uploadreport
struct SearchbarModel: Codable {
    let status: Bool
    let search: [Search]
}

// MARK: - Search
struct Search: Codable {
    let userid: Int
    let name, contactNo: String

    enum CodingKeys: String, CodingKey {
        case userid = "Userid"
        case name = "Name"
        case contactNo = "ContactNo"
    }
}

