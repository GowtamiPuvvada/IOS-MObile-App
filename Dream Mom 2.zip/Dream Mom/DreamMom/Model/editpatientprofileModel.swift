//
//  editpatientprofileModel.swift
//  DreamMom
//
//  Created by vyas police on 30/12/23.
//

import Foundation

// MARK: - Welcome
struct editpatientprofileModel: Codable {
    let status : Bool
    let message: String
}
