//
//  sviewadviceModel.swift
//  DreamMom
//
//  Created by vyas police on 18/12/23.
//

import Foundation

// MARK: - Temperatures
struct sviewadviceModel: Codable {
    let status: Bool
    let sviewadvices: [Sviewadvice]
}

// MARK: - Sviewadvice
struct Sviewadvice: Codable {
    let id, userid, date, addadvices: String

    enum CodingKeys: String, CodingKey {
        case id
        case userid = "Userid"
        case date = "Date"
        case addadvices = "Addadvices"
    }
}
