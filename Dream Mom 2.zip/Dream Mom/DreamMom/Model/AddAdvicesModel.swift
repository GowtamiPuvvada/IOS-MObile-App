//
//  AddAdvicesModel.swift
//  DreamMom
//
//  Created by vyas police on 18/12/23.
//

import Foundation
struct AddAdvicesModel: Codable {
    let status: Bool
    let message: String
}
