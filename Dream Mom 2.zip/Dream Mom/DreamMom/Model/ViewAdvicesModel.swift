//
//  ViewAdvicesModel.swift
//  DreamMom
//
//  Created by vyas police on 18/12/23.
//

import Foundation

// MARK: - Temperatures
struct ViewAdvicesModel: Codable {
    let status: Bool
    let viewadvices: [Viewadvice]
}

// MARK: - Viewadvice
struct Viewadvice: Codable {
    let id, userid, date, addadvices: String

    enum CodingKeys: String, CodingKey {
        case id
        case userid = "Userid"
        case date = "Date"
        case addadvices = "Addadvices"
    }
}
