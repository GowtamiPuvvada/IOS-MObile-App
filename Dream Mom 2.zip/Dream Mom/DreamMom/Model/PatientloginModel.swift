//
//  PatientloginModel.swift
//  DreamMom
//
//  Created by vyas police on 20/12/23.
//
import Foundation

// MARK: - Temperatures
struct PatientloginModel: Codable {
    let status: Bool
    let message, userID: String

    enum CodingKeys: String, CodingKey {
        case status, message
        case userID = "user_id"
    }
}
