//
//  AddPatientModel.swift
//  DreamMom
//
//  Created by SAIL on 11/12/23.
//

import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    let status: Bool
    let message: String
}
