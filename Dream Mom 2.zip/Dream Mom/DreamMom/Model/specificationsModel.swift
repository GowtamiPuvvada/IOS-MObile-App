//
//  specificationsModel.swift
//  DreamMom
//
//  Created by vyas police on 04/01/24.
//

import Foundation

// MARK: - Uploadreport
struct SpecificationsModel: Codable {
    let status: Bool
    let specifications: [SpecificationData]
}

// MARK: - Viewadvice
struct SpecificationData: Codable {
    let specifications: String

    enum CodingKeys: String, CodingKey {
        case specifications = "Specifications"
    }
}
