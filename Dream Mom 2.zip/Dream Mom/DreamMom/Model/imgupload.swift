import Foundation

// MARK: - Uploadreport
struct imageupload: Codable {
    let status: Bool
    let message: String
    
}
                                    
