// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)


import Foundation

// MARK: - Welcome
struct doctorProfile: Codable {
    let status: Bool
        let doctorDetails: DoctorDetails
    }

// MARK: - DoctorDetails
struct DoctorDetails: Codable {
    let drUserid: String
    let drName, email, contactNo, designation: String

    enum CodingKeys: String, CodingKey {
        case drUserid = "dr_userid"
        case drName = "dr_name"
        case email
        case contactNo = "contact_no"
        case designation
    }
}
