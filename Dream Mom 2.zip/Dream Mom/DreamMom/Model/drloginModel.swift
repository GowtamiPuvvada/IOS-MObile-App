//
//  drloginModel.swift
//  DreamMom
//
//  Created by SAIL on 01/12/23.
//
import Foundation

// MARK: - Welcome
struct drloginModel: Codable {
    let status : Bool
    let message: String
}

struct EditUserData: Codable {
    let status : Bool
    let message: String
}

