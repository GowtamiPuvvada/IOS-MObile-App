//
//  ViewPatientListModel.swift
//  DreamMom
//
//  Created by SAIL on 14/12/23.
//

import Foundation

// MARK: - Uploadreport
struct ViewPatientListModel: Codable {
    let status: Bool
    let data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    let userid: Int
    let name, contactNo: String

    enum CodingKeys: String, CodingKey {
        case userid = "Userid"
        case name = "Name"
        case contactNo = "ContactNo"
    }
}
