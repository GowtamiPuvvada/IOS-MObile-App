//
//  monthdayModel.swift
//  DreamMom
//
//  Created by SAIL on 07/02/24.
//

import Foundation
struct monthdayModel: Codable {
    let status: Bool
    let days: Days
}
struct Days: Codable {
    let days: String
}
