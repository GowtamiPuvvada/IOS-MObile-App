//
//  cycleupdatePModel.swift
//  DreamMom
//
//  Created by vyas police on 21/12/23.
//

import Foundation

// MARK: - Temperatures
struct cycleupdatePModel: Codable {
    let status: Bool
    let message: String
}
