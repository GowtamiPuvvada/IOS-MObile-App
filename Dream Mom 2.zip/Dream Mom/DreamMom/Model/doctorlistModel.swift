//
//  doctorlistModel.swift
//  DreamMom
//
//  Created by k. Dharani on 09/03/24.
//

import Foundation

// MARK: - Welcome
struct doctorlistModel: Codable {
    let status: Bool
    let data: [doctorlist]
}

// MARK: - Datum
struct doctorlist: Codable {
    let drUserid: Int
    let drName: String
    let designation: Designation

    enum CodingKeys: String, CodingKey {
        case drUserid = "dr_userid"
        case drName = "dr_name"
        case designation
    }
}

enum Designation: String, Codable {
    case designation = "designation"
    case empty = ""
    case ortho = "ortho"
    case unknown // Add a case for unknown designation

    // Implement custom decoding logic to handle unknown values
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        let rawValue = try container.decode(String.self)
        // Attempt to map the raw value to a known case, or use unknown for unknown values
        self = Designation(rawValue: rawValue) ?? .unknown
    }
}

