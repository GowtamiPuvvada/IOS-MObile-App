//
//  graphModel.swift
//  DreamMom
//
//  Created by vyas police on 03/01/24.
//

import Foundation

// MARK: - Uploadreport
struct graphModel: Codable {
    let status: Bool
    let message: String
    let data: [graph]
}

// MARK: - Datum
struct graph: Codable {
    let date: String
    let endometrium, leftOvary, rightOvary: Float
}
