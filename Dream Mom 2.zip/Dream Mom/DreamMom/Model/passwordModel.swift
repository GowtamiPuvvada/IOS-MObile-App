//
//  passwordModel.swift
//  DreamMom
//
//  Created by vyas police on 09/01/24.
//

import Foundation
struct passwordModel: Codable {
    let status: Bool
    let message: String
}
