//
//  AddspouseModel.swift
//  DreamMom
//
//  Created by SAIL on 12/12/23.
//

import Foundation

// MARK: - Welcome
struct AddspouseModel: Codable {
    let status: Bool
    let message: String
}
