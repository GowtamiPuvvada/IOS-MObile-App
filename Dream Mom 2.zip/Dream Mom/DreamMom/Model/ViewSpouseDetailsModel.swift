//
//  ViewSpouseDetailsModel.swift
//  DreamMom
//
//  Created by SAIL on 15/12/23.
//

import Foundation

// MARK: - Temperatures
struct ViewSpouseDetailsModel: Codable {
    let status: Bool
    let spouseDetails: SpouseDetails
}

// MARK: - SpouseDetails
struct SpouseDetails: Codable {
    let id, userid, name, contactnumber: String
    let bloodgroup, height, weight, age: String
    let medicalhistory: String

    enum CodingKeys: String, CodingKey {
        case id
        case userid = "Userid"
        case name = "Name"
        case contactnumber = "Contactnumber"
        case bloodgroup = "Bloodgroup"
        case height = "Height"
        case weight = "Weight"
        case age = "Age"
        case medicalhistory = "Medicalhistory"
    }
}
