//
//  cycleviewModel.swift
//  DreamMom
//
//  Created by vyas police on 19/12/23.
//
import Foundation

// MARK: - Temperatures
struct cycleviewModel: Codable {
    let status: Bool
    let cycleupdate: [Cycleupdate]
}

// MARK: - Cycleupdate
struct Cycleupdate: Codable {
    let id, userid, date: String

    enum CodingKeys: String, CodingKey {
        case id
        case userid = "Userid"
        case date
    }
}
