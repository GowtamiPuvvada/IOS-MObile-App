//
//  AddReportsModel.swift
//  DreamMom
//
//  Created by vyas police on 15/12/23.
//

import Foundation

// MARK: - Temperatures
struct AddReportsModel: Codable {
    let status: Bool
    let message: String
}
