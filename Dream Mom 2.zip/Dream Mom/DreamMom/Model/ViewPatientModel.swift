//
//  ViewPatientModel.swift
//  DreamMom
//
//  Created by SAIL on 14/12/23.
//

import Foundation

// MARK: - Temperatures
struct ViewPatientModel: Codable {
    let status: Bool
    let patientDetails: PatientDetails
}

// MARK: - PatientDetails
struct PatientDetails: Codable {
    let contactNo : String
    let userid, name : String
    let age, gender : String
    let height, weight : String
    let address, marriageyear, bloodgroup, medicalhistory: String
    let specifications: String

    enum CodingKeys: String, CodingKey {
       
        case userid = "Userid"
        case name = "Name"
        case contactNo = "ContactNo"
        case age = "Age"
        case gender = "Gender"
        case height = "Height"
        case weight = "Weight"
        case address = "Address"
        case marriageyear = "Marriageyear"
        case bloodgroup = "Bloodgroup"
        case medicalhistory = "Medicalhistory"
        case specifications = "Specifications"
    }
}
