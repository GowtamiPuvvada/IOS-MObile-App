//
//  AddSpecificationsModel.swift
//  DreamMom
//
//  Created by SAIL on 13/12/23.
//

import Foundation

// MARK: - Temperatures
struct AddSpecificationsModel: Codable {
    let status: Bool
    let message: String
}
