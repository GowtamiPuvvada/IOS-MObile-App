//
//  ViewMedicationsModel.swift
//  DreamMom
//
//  Created by SAIL on 18/12/23.
//

import Foundation


// MARK: - Temperatures
struct ViewMedicationsModel : Codable {
    let status: Bool
    let patientDetails: [PatientDetail]
}

// MARK: - PatientDetail
struct PatientDetail: Codable {
    let id, userid, medicineName, time: String
    let quantity, date: String
    let when: String

    enum CodingKeys: String, CodingKey {
        case id
        case userid = "Userid"
        case medicineName = "MedicineName"
        case time = "Time"
        case quantity, date, when
    }
}

enum When: String, Codable {
    case empty = ""
    case f = "f"
}
