//
//  ViewStatusModel.swift
//  DreamMom
//
//  Created by SAIL on 18/12/23.
//
import Foundation

// MARK: - Temperatures
struct ViewStatusModel: Codable {
    let status: Bool
    let viewreport: [Viewreport]
}

// MARK: - Viewreport
struct Viewreport: Codable {
    let id, userid, date, day: String
    let endometrium, leftovery, rightovery: String

    enum CodingKeys: String, CodingKey {
        case id
        case userid = "Userid"
        case date, day
        case endometrium = "Endometrium"
        case leftovery = "Leftovery"
        case rightovery = "Rightovery"
    }
}
