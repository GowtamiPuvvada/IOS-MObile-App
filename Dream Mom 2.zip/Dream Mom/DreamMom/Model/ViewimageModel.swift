//
//  ViewimageModel.swift
//  DreamMom
//
//  Created by vyas police on 10/01/24.
//

import Foundation

// MARK: - Uploadreport
struct ViewimageModel: Codable {
    let status: Bool
    let message: String
    let images : [String]
    let date : [String]
    let  day: [String]
}
//struct Image: Codable {
//    let url: String
//    let date: String
//}
