//
//  patientlogindisplayModel.swift
//  DreamMom
//
//  Created by vyas police on 20/12/23.
//

import Foundation

// MARK: - Temperatures
struct patientlogindisplayModel: Codable {
    let status: Bool
    let patientdisplay: [Patientdisplay]
}

// MARK: - Patientdisplay
struct Patientdisplay: Codable {
    let userid, name, contactNo, marriageyear: String
    let bloodgroup: String

    enum CodingKeys: String, CodingKey {
        case userid = "Userid"
        case name = "Name"
        case contactNo = "ContactNo"
        case marriageyear = "Marriageyear"
        case bloodgroup = "Bloodgroup"
    }
}
