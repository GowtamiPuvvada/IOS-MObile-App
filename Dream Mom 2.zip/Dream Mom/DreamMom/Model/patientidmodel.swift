//
//  patientidmodel.swift
//  DreamMom
//
//  Created by k. Dharani on 11/03/24.
//
import Foundation

// MARK: - Welcome
struct patientidmodel: Codable {
    let status: Bool
    let message: String
    let userid: Int

    enum CodingKeys: String, CodingKey {
        case status, message
        case userid = "Userid"
    }
}

