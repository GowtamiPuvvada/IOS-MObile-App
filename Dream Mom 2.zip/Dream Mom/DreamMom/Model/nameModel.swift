//
//  nameModel.swift
//  DreamMom
//
//  Created by SAIL on 24/01/24.
//


import Foundation

struct nameModel: Codable {
    let status: Bool
    let name: Name
}

struct Name: Codable {
    let userid, name: String

    enum CodingKeys: String, CodingKey {
        case userid = "Userid"
        case name = "Name"
    }
}
