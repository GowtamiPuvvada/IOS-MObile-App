-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 18, 2024 at 09:36 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `infertility`
--

-- --------------------------------------------------------

--
-- Table structure for table `addpatient`
--

CREATE TABLE `addpatient` (
  `Userid` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL DEFAULT 'name',
  `ContactNo` varchar(50) NOT NULL DEFAULT 'contactnumber',
  `Age` varchar(50) NOT NULL DEFAULT 'age',
  `Gender` varchar(50) NOT NULL DEFAULT 'gender',
  `Height` varchar(50) NOT NULL DEFAULT 'height',
  `Weight` varchar(50) NOT NULL DEFAULT 'weight',
  `Address` varchar(700) NOT NULL DEFAULT 'address',
  `Marriageyear` varchar(50) NOT NULL DEFAULT 'yom',
  `Bloodgroup` varchar(50) NOT NULL DEFAULT 'bloodgroup',
  `Medicalhistory` varchar(1000) NOT NULL DEFAULT 'medicalhistory',
  `Specifications` varchar(1000) NOT NULL DEFAULT 'NO SPECIFICATIONS SPECIFIED',
  `password` varchar(50) NOT NULL DEFAULT 'WELCOME',
  `repassword` varchar(50) NOT NULL DEFAULT 'WELCOME'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addpatient`
--

INSERT INTO `addpatient` (`Userid`, `Name`, `ContactNo`, `Age`, `Gender`, `Height`, `Weight`, `Address`, `Marriageyear`, `Bloodgroup`, `Medicalhistory`, `Specifications`, `password`, `repassword`) VALUES
(205, 'Geetha1', '321456987', '22', 'MALE', '5.5', '45', 'Chennai', '2006', 'o ve', 'Nill', '', '2', '2'),
(206, '', '', '', '', '', '', '', '', '', '', 'NO SPECIFICATIONS SPECIFIED', '', ''),
(207, '', '', '', '', '', '', '', '', '', '', 'NO SPECIFICATIONS SPECIFIED', '', ''),
(208, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(209, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(210, 'sushma', '9087654321', '3', 'Male', '.', 'l', 'L', '3', '3', 'L', 'E', 'WELCOME', 'WELCOME'),
(211, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(212, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(213, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(214, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(215, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(216, '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'NO SPECIFICATIONS SPECIFIED', '1', '1'),
(217, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(218, 'sushma', '9087654321', '3', 'Male', 'a11', '1', '1', '3', '3', '1', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(219, 'sushma', '9087654321', '3', 'Male', '6', '6', '6', '3', '3', '6', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(220, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME'),
(221, 'name', 'contactnumber', 'age', 'gender', 'height', 'weight', 'address', 'yom', 'bloodgroup', 'medicalhistory', 'NO SPECIFICATIONS SPECIFIED', 'WELCOME', 'WELCOME');

-- --------------------------------------------------------

--
-- Table structure for table `addreport`
--

CREATE TABLE `addreport` (
  `id` int(11) NOT NULL,
  `Userid` varchar(20) NOT NULL,
  `date` varchar(40) NOT NULL,
  `day` varchar(40) NOT NULL,
  `Endometrium` float(24,6) NOT NULL,
  `Leftovery` float(24,6) NOT NULL,
  `Rightovery` float(24,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addreport`
--

INSERT INTO `addreport` (`id`, `Userid`, `date`, `day`, `Endometrium`, `Leftovery`, `Rightovery`) VALUES
(36, '205', '2024-02-19 06:29:57  0000', 'Monday', 0.200000, 0.300000, 0.300000),
(38, '205', '2024-02-19 06:54:50  0000', 'Monday', 0.500000, 0.500000, 0.900000),
(39, '205', '2024-03-04 14:11:46  0000', 'Monday', 0.030000, 0.040000, 0.070000),
(40, '205', '2024-03-05 09:39:41  0000', 'Tuesday', 0.200000, 0.300000, 0.800000),
(41, '205', '2024-03-07 04:36:55  0000', 'Thursday', 0.300000, 0.300000, 0.300000),
(42, '205', '2024-03-07 04:37:36  0000', 'Thursday', 7.000000, 7.000000, 7.000000),
(43, '205', '2024-03-07 09:14:16  0000', 'Thursday', 0.300000, 0.400000, 0.500000),
(44, '205', '2024-03-07 14:30:38  0000', 'Thursday', 0.000000, 0.000000, 0.000000),
(45, '205', '2024-03-08 03:31:27  0000', 'Friday', 0.300000, 0.400000, 0.400000),
(46, '205', '2024-03-12 13:51:33  0000', 'Tuesday', 0.300000, 0.400000, 0.030000);

-- --------------------------------------------------------

--
-- Table structure for table `addspouse`
--

CREATE TABLE `addspouse` (
  `id` int(11) NOT NULL,
  `Userid` varchar(20) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Contactnumber` varchar(20) NOT NULL,
  `Bloodgroup` varchar(10) NOT NULL,
  `Height` varchar(20) NOT NULL,
  `Weight` varchar(20) NOT NULL,
  `Age` varchar(50) NOT NULL,
  `Medicalhistory` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addspouse`
--

INSERT INTO `addspouse` (`id`, `Userid`, `Name`, `Contactnumber`, `Bloodgroup`, `Height`, `Weight`, `Age`, `Medicalhistory`) VALUES
(38, '205', 'Krishna', '789654123', 'o ve', '12', '120', '1000533', 'hi'),
(39, '2059', 'ki', '89', 'kk', '7', '8', '88', ''),
(40, '1109', 'ki', '89', 'kk', '7', '8', '88', ''),
(41, '1100', 'ki', '89', 'kk', '7', '8', '88', ''),
(42, '11000', 'ki', '89', 'kk', '7', '8', '88', ''),
(43, '20599999', '', '', '', '', '', '', ''),
(44, '1114', 'ki', '89', 'kk', '7', '8', '88', ''),
(45, '123', 'ffsd', '9087654321', 'A ', '9', '9', '18', 'Ca'),
(46, '6', 'ki', '89', 'kk', '7', '8', '88', ''),
(47, '0', 'uyt', '0986754213', '6', '1', '3', '1', 'G'),
(48, '11=', 'ki', '89', 'kk', '7', '90', '88', ''),
(49, '121', 'ki', '89', 'kk', '7', '8', '88', ''),
(50, '1231@', 'ki', '89', 'kk', '7', '8', '88', ''),
(51, '@', 'ki', '89', 'kk', '7', '8', '88', ''),
(52, 'I', 'uyt', '0986754213', '6', '1', '3', '1', 'Gfd'),
(53, '001', 'ki', '89', 'kk', '7', '8', '88', ''),
(54, '002', 'ki', '89', 'kk', '7', '8', '88', ''),
(55, '159', 'ki', '89', 'kk', '7', '8', '88', ''),
(56, '89', 'ki', '9632587410', 'kk', '7', '8', '88', ''),
(57, '5p', 'ki', '0123654789', 'kk', '7', '8', '88', ''),
(58, 'cod', 'gym', '9876543210', 'kk', '7', '8', '88', ''),
(59, '1', 'gowtami', '1236547890', 'B ', '5.3ft', '59', '41 years', ''),
(60, '2', 'b', '7896541230', 'A-', '5.3', '55', '49 years', ''),
(61, 'w', 'b', '1230654789', 'A-', '5.3', '99', '14 years', 'Hi'),
(62, '12', 'asdf', '9876543210', 'A ', '5.3', '88', '38', 'Nill'),
(63, 'dv', 'fs', '0987654321', 'A ', '9', '9', '18', 'Sd'),
(64, '9', 'uyt', '0986754213', '6', '1', '3', '1', 'Ax'),
(65, 'g', 'uyt', '0986754213', '6', '1', '3', '1', 'X. X'),
(66, '1234', 'uyt', '1234567890', '6', '1', '3', '1', 'Big'),
(67, '12345', 'uyt', '0986754211', '6', '1', '3', '1', 'Engine'),
(68, '123456', 'uyt', '0986754213', '6', '1', '3', '1', 'Cds'),
(69, '9876', 'uyt', '0986754213', '6', '1', '3', '1', 'Ewkb'),
(70, '09', 'uyt', '0986754213', '6', '1', '3', '1', 'No'),
(71, '78', 'uyt', '0986754213', '6', '1', '3', '1', '3we'),
(72, '532523r23r', 'uyt', '0986754213', '6', '1', '3', '1', 'Sdsds'),
(73, 'l', 'uyt', '0986754219', '6', '1', '3', '1', 'C'),
(74, 'Fsg', 'uyt', '0986754210', '6', '1', '3', '18', 'D'),
(75, 'we', 'uyt', '0986754211', '6', '1', '3', '1', 'Do'),
(76, 'jk', 'uyt', '0986754219', '6', '1', '3', '1', 'Jjhb'),
(77, 'John', 'uyt', '0986754212', '6', '1', '3', '1', 'T'),
(78, 'd', 'uyt', '0986754211', '6', '1', '3', '1', 'She'),
(79, 'd8', 'uyt', '0986754213', '6', '1', '3', '1', 'Do'),
(80, '09a', 'uyt', '0986754213', 'A ', '1', '3', '18', 'Earth'),
(81, 'ok', 'uyt', '0986754213', '6', '1', '3', '1', 'Efd'),
(82, '00', 'uyt', '0986754213', '6', '1', '3', '1', 'Enter Medical History'),
(83, '-', 'uyt', '0986754213', '6', '1', '3', '1', 'Enter Medical History'),
(84, 'mnbv', 'uyt', '0986754213', '6', '1', '3', '1', 'Enter Medical History'),
(85, '09l', 'uyt', '0986754213', 'A ', '1', '3', '18', 'Ha'),
(86, '1,', 'uyt', '0986754211', '6', '1', '3', '1', 'A'),
(87, '210', 'uyt', '0986754213', '6', '1', '3', '1', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `advices`
--

CREATE TABLE `advices` (
  `id` int(11) NOT NULL,
  `Userid` varchar(20) NOT NULL,
  `Date` date NOT NULL,
  `Addadvices` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `advices`
--

INSERT INTO `advices` (`id`, `Userid`, `Date`, `Addadvices`) VALUES
(26, '205', '0000-00-00', 'nothing\r\nnothing'),
(27, '205', '2023-12-18', 'Gd'),
(28, '205', '2023-12-18', 'Hii'),
(29, '205', '2023-12-18', 'Noil'),
(30, '205', '2023-12-18', 'Enter your text here...'),
(31, '205', '2023-12-18', 'Enter your text here...'),
(32, '205', '2023-12-19', 'Hlo'),
(33, '205', '2023-12-19', 'Enter your text here...'),
(34, '', '0000-00-00', 'nothing'),
(35, '205', '2023-12-21', 'Enter your text here...'),
(36, '205', '2023-12-21', 'Nhfnh'),
(37, '205', '2023-12-21', 'Enter your text here...'),
(38, '205', '2023-12-21', 'Asd'),
(39, '205', '2024-01-29', 'Enter your text here...\nEnter your text here...\nGood\nNice ra\nHlo\n let trimmedAdvice = advice.trimmingCharacters(in: .whitespacesAndNewlines)\n        if trimmedAdvice.isEmpty || trimmedAdvice == placeholderText {\n            self.showAlert(title: \"Error\", message: \"Please add advice\")\n            return\n        }\n\n        let dateformatter = DateFormatter()\n        dateformatter.dateFormat = \"yyyy-MM-dd\" // Change the date format here\n        let formattedDate = dateformatter.string(from: Time ?? Date())\n\n        let formData: [String: String] = [\n'),
(40, '1100', '2024-01-29', 'Good'),
(41, '1109', '2024-01-29', 'Gud\nNice'),
(42, '205', '2024-01-31', ' Bfg'),
(43, '2059', '2024-01-31', ' Bcfgx '),
(44, '205', '2024-02-01', 'Dghr\nRfv'),
(45, '205', '2024-02-03', 'Fvg\nGood'),
(46, '205', '2024-02-06', 'D'),
(47, '205', '2024-03-04', 'Good'),
(48, '205', '2024-03-07', 'Swc\n N'),
(49, '205', '2024-03-08', 'Good medical report');

-- --------------------------------------------------------

--
-- Table structure for table `cycleupdate`
--

CREATE TABLE `cycleupdate` (
  `id` int(11) NOT NULL,
  `Userid` varchar(20) NOT NULL,
  `date` varchar(40) NOT NULL,
  `days` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cycleupdate`
--

INSERT INTO `cycleupdate` (`id`, `Userid`, `date`, `days`) VALUES
(1, '205', '2024/03/10', '2nd'),
(2, '2059', '2024/02/10', '6th');

-- --------------------------------------------------------

--
-- Table structure for table `datep`
--

CREATE TABLE `datep` (
  `id` int(11) NOT NULL,
  `userid` varchar(111) NOT NULL,
  `datep` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `datep`
--

INSERT INTO `datep` (`id`, `userid`, `datep`) VALUES
(1, '205', '2024-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `degignation`
--

CREATE TABLE `degignation` (
  `id` int(11) NOT NULL,
  `role` varchar(11) NOT NULL,
  `did` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `degignation`
--

INSERT INTO `degignation` (`id`, `role`, `did`) VALUES
(1, 'doctor', 1),
(2, 'paitent', 2);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_profile`
--

CREATE TABLE `doctor_profile` (
  `dr_userid` int(11) NOT NULL,
  `dr_name` varchar(30) NOT NULL DEFAULT 'welcome',
  `email` varchar(20) NOT NULL DEFAULT '@gmail.com',
  `password` varchar(20) NOT NULL DEFAULT 'welcome',
  `designation` varchar(20) NOT NULL DEFAULT 'designation',
  `contact_no` varchar(20) NOT NULL DEFAULT 'contactnumber',
  `repassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_profile`
--

INSERT INTO `doctor_profile` (`dr_userid`, `dr_name`, `email`, `password`, `designation`, `contact_no`, `repassword`) VALUES
(1920, 'kavya', '1233@gmail.com', '1234', 'ortho', '1234567890', '1234'),
(192011305, 'gowtami', '123@gmail.com', '1', 'ortho', '1234567890', '1'),
(192011311, '', '', 'welcome', '', '', ''),
(192011312, '', '', 'welcome', '', '', ''),
(192011313, '', '', 'welcome', '', '', ''),
(192011314, 'gowtami', '123@gmail.com', 'welcome', 'ortho', '1234567890', ''),
(192011315, '', '', 'welcome', '', '', ''),
(192011316, '', '', 'welcome', '', '', ''),
(192011317, '', '', 'welcome', '', '', ''),
(192011318, '1', '1@gmail.com', 'welcome', 'ortho', '0987654321', ''),
(192011319, '2', '123@gmail.com', 'welcome', 'ortho', '1234567890', ''),
(192011320, '', '', 'welcome', '', '', ''),
(192011321, '', '1@gmail.com', '', '', '1234567890', ''),
(192011322, '', '', '', '', '', ''),
(192011323, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011324, '', '', '', 'designation', '', ''),
(192011325, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011326, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011327, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011328, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011329, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011330, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011331, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011332, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011333, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011334, 'I', '123@gmail.com', 'welcome', 'h', '1234567890', ''),
(192011335, 'kavya', 'gowtami@gmail.com', 'welcome', 'ortho', '1234567890', ''),
(192011336, 'Kacy', 'h@gmail.com', 'welcome', 'i', '9123456789', ''),
(192011337, 'k', '1@gmail.com', 'welcome', 'o', '1234567890', ''),
(192011338, 'd', 's@gmail.com', 'welcome', 'o', '1234567890', ''),
(192011339, 'welcome', '@gmail.com', 'welcome', 'designation', 'contactnumber', ''),
(192011340, 'jhjhj', 'test@gmail.com', 'welcome', 'adds', '6676767678', '');

-- --------------------------------------------------------

--
-- Table structure for table `medicationdetails`
--

CREATE TABLE `medicationdetails` (
  `id` int(11) NOT NULL,
  `Userid` varchar(20) NOT NULL,
  `MedicineName` varchar(30) NOT NULL,
  `Time` varchar(30) NOT NULL,
  `quantity` varchar(15) NOT NULL,
  `date` date NOT NULL,
  `when` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicationdetails`
--

INSERT INTO `medicationdetails` (`id`, `Userid`, `MedicineName`, `Time`, `quantity`, `date`, `when`) VALUES
(51, '205', 'solo', '2023-12-18 08:5', '11', '0000-00-00', ''),
(52, '205', 'sasa', '2023-12-18 13:1', '11', '0000-00-00', ''),
(53, '205', 'sasa', '2024-01-11 06:0', '11', '0000-00-00', ''),
(54, '205', 'sasa', '2024-01-24 10:02:25  0000', '11', '0000-00-00', ''),
(55, '205', '', '2024-01-24 10:08:31  0000', '', '0000-00-00', ''),
(56, '205', 'sasa', '(Function)', '11', '0000-00-00', ''),
(57, '205', 'sasa', '(Function)', '11', '0000-00-00', ''),
(58, '205', 'dolo', '(Function)', '11', '0000-00-00', ''),
(59, '205', 'solo', '(Function)', '1', '0000-00-00', ''),
(60, '205', 'dolo', 'lunch', '1', '0000-00-00', ''),
(61, '205', '', '', '', '2024-01-29', ''),
(62, '205', 'sasa', 'AM', '11', '2024-01-31', ''),
(63, '205', 'sasa', 'AM', '11', '2024-02-02', ''),
(64, '205', 'solo', 'am', '9', '2024-03-04', ''),
(65, '205', 'solo', 'afternon', '1', '2024-03-05', ''),
(66, '205', 'solo', '3times', '2', '2024-03-07', ''),
(67, '205', 'k', 'k', 'k', '2024-03-07', ''),
(68, '205', 'solo', '4 times', '1', '2024-03-08', ''),
(69, '', '', '', '', '2024-03-12', ''),
(70, '', '', '', '', '2024-03-12', 'a'),
(71, '205', 'f', 'f', 'f', '2024-03-12', 'f'),
(72, '205', 's', 's', 's', '2024-03-12', 's');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `role` varchar(10) NOT NULL,
  `Userid` varchar(14) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `reenterpassword` varchar(22) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `PhoneNumber` bigint(11) NOT NULL,
  `specification` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `update`
--

CREATE TABLE `update` (
  `id` int(11) NOT NULL,
  `Userid` int(11) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uploadimage`
--

CREATE TABLE `uploadimage` (
  `id` int(11) NOT NULL,
  `Userid` int(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  `day` varchar(5) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uploadimage`
--

INSERT INTO `uploadimage` (`id`, `Userid`, `image`, `day`, `date`) VALUES
(113, 205, 'videos/img_65d2fac82eaa46.61598299.jpeg', '5', '2024-02-19'),
(114, 205, 'videos/img_65e6ea89cbf987.06499072.jpg', '2', '2024-03-05'),
(115, 205, 'videos/img_65e986262ea4b2.04943701.jpg', '6', '2024-03-07'),
(116, 205, 'videos/img_65ea8919135ef5.68514492.jpg', '7', '2024-03-08'),
(117, 205, 'videos/img_65f3e9d4d63f21.99102866.jpg', '5', '2024-03-15'),
(118, 205, 'videos/img_65f3fadfe0de88.21691588.jpg', '5', '2024-03-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addpatient`
--
ALTER TABLE `addpatient`
  ADD PRIMARY KEY (`Userid`);

--
-- Indexes for table `addreport`
--
ALTER TABLE `addreport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addspouse`
--
ALTER TABLE `addspouse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advices`
--
ALTER TABLE `advices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cycleupdate`
--
ALTER TABLE `cycleupdate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datep`
--
ALTER TABLE `datep`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `degignation`
--
ALTER TABLE `degignation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_profile`
--
ALTER TABLE `doctor_profile`
  ADD PRIMARY KEY (`dr_userid`);

--
-- Indexes for table `medicationdetails`
--
ALTER TABLE `medicationdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `update`
--
ALTER TABLE `update`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploadimage`
--
ALTER TABLE `uploadimage`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addpatient`
--
ALTER TABLE `addpatient`
  MODIFY `Userid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;

--
-- AUTO_INCREMENT for table `addreport`
--
ALTER TABLE `addreport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `addspouse`
--
ALTER TABLE `addspouse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `advices`
--
ALTER TABLE `advices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `cycleupdate`
--
ALTER TABLE `cycleupdate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `datep`
--
ALTER TABLE `datep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `degignation`
--
ALTER TABLE `degignation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctor_profile`
--
ALTER TABLE `doctor_profile`
  MODIFY `dr_userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192011341;

--
-- AUTO_INCREMENT for table `medicationdetails`
--
ALTER TABLE `medicationdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `update`
--
ALTER TABLE `update`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uploadimage`
--
ALTER TABLE `uploadimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
