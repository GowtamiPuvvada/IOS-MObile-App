<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('con.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $userid = $_POST['userId'];
    $password = $_POST['password'];

    // Check if the user exists in the database
    $check_sql = "SELECT * FROM doctor_profile WHERE dr_userid = '$userid' AND password = '$password'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // User exists, return success as true
        $response = array('status' => true, 'message' => 'User login successful.');
        echo json_encode($response);
    } else {
        // User does not exist or incorrect password, return success as false
        $response = array('status' => false, 'message' => 'Invalid userid or password.');
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => false, 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
