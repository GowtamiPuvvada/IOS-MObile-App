<?php
require_once('con.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate if all fields are provided
    $required_fields = ['dr_userid', 'dr_name', 'email', 'designation', 'contact_no'];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $response = array('status' => false, 'message' => 'All fields are required.');
            echo json_encode($response);
            exit; // Stop execution if any field is empty
        }
    }

    // Validate email format
    $email = $_POST['email'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@gmail\.com$/', $email)) {
        $response = array('status' => false, 'message' => 'Invalid email format. Must be a valid Gmail address.');
        echo json_encode($response);
        exit;
    }

    // Validate contact number format
    $contact_no = $_POST['contact_no'];
    if (!preg_match('/^\d{10}$/', $contact_no)) {
        $response = array('status' => false, 'message' => 'Invalid contact number format. Must be 10 numerical digits.');
        echo json_encode($response);
        exit;
    }

    // Get input data from the application
    $dr_userid = $_POST['dr_userid'];
    $dr_name = $_POST['dr_name'];
    $designation = $_POST['designation'];

    // Update data in the doctor_profile table
    $sql = "UPDATE doctor_profile SET dr_name = ?, email = ?, designation = ?, contact_no = ? WHERE dr_userid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $dr_name, $email, $designation, $contact_no, $dr_userid);

    if ($stmt->execute()) {
        // Successful update
        $response = array('status' => true, 'message' => 'Doctor details updated successfully.');
        echo json_encode($response);
    } else {
        // Error in database update
        $response = array('status' => false, 'message' => 'Error: ' . $conn->error);
        echo json_encode($response);
    }

    $stmt->close();
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => false, 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
