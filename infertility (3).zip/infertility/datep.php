<?php
require_once('con.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userid = $_POST['userid'];
    $inputDate = $_POST['updatedate']; // Assuming this is in 'YYYY-MM-DD' format

    // First, either update or insert the record in `cycleupdate`
    $check_sql = "SELECT Userid FROM cycleupdate WHERE Userid = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("s", $userid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        if ($result->num_rows > 0) {
            // User exists, update the record
            $update_sql = "UPDATE cycleupdate SET date = ? WHERE Userid = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ss", $inputDate, $userid);
            $update_stmt->execute();
        } else {
            // User doesn't exist, insert new record
            $insert_sql = "INSERT INTO cycleupdate (Userid, date) VALUES (?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("ss", $userid, $inputDate);
            $insert_stmt->execute();
        }
        
        // Then, update or insert the date in `datep` table
        // Calculate the date 3 months after the input date
        $dateThreeMonthsAfter = date('Y-m-d', strtotime($inputDate . ' +3 months'));

        // Check if the user exists in `datep`
        $check_datep_sql = "SELECT userid FROM datep WHERE userid = ?";
        $check_datep_stmt = $conn->prepare($check_datep_sql);
        $check_datep_stmt->bind_param("s", $userid);
        $check_datep_stmt->execute();
        $datep_result = $check_datep_stmt->get_result();

        if ($datep_result->num_rows > 0) {
            // User exists in `datep`, update the record
            $update_datep_sql = "UPDATE datep SET datep = ? WHERE userid = ?";
            $update_datep_stmt = $conn->prepare($update_datep_sql);
            $update_datep_stmt->bind_param("ss", $dateThreeMonthsAfter, $userid);
            $update_datep_stmt->execute();
        } else {
            // User doesn't exist in `datep`, insert new record
            $insert_datep_sql = "INSERT INTO datep (userid, datep) VALUES (?, ?)";
            $insert_datep_stmt = $conn->prepare($insert_datep_sql);
            $insert_datep_stmt->bind_param("ss", $userid, $dateThreeMonthsAfter);
            $insert_datep_stmt->execute();
        }

        echo json_encode(['status' => true, 'message' => 'Operation successful.']);
    } else {
        echo json_encode(['status' => false, 'message' => 'Error in query execution: ' . $conn->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => false, 'message' => 'Invalid request method.']);
}
?>
