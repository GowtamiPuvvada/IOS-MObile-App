<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('con.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $userid = $_POST['userid'];
    $medicinename = $_POST['medicinename'];
    $quantity = $_POST['quantity'];
    $time = $_POST['time'];
    $when = $_POST['when'];
    
    // Get the current date
    $date = date("Y-m-d");

    // Insert data into the medicationdetails table
    $sql = "INSERT INTO medicationdetails (Userid, MedicineName, Time, quantity, date, `when`) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Bind parameters and execute the query
        $stmt->bind_param('ssssss', $userid, $medicinename, $time, $quantity, $date, $when);
        if ($stmt->execute()) {
            // Successful insertion
            $response = array('status' => true, 'message' => 'Medication was added successfully.');
            echo json_encode($response);
        } else {
            // Error in database insertion
            $response = array('status' => false, 'message' => 'Error: ' . $stmt->error);
            echo json_encode($response);
        }
        $stmt->close();
    } else {
        // Error preparing the SQL statement
        $response = array('status' => false, 'message' => 'Error preparing the SQL statement.');
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => false, 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
